export class SearchResponse {

    EntityType: string;
    Id: number;
    SecondaryId: number;
    ImageText: string;
    ImageUrl: string;
    Line1: string;
    Line2: string;
    Line3: string;
    MatchedOnValues: string;

}
