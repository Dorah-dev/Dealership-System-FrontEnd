import {Injectable} from '@angular/core';
// import {Headers, Http, RequestOptions, Response, URLSearchParams} from "@angular/http";
import 'rxjs/add/operator/map';

import {AuthService} from '../auth/services/auth.service';
import {environment} from '../../environments/environment';
import {Observable, Subject} from 'rxjs';
import {HttpClient, HttpParams, HttpResponse} from '@angular/common/http';
import {ApiService} from '../core/api/api.service';


@Injectable()
export class SearchService {

    toggleSearch: Subject<any>;
    selectObject: Subject<{}>;

    constructor(private http: HttpClient, private authService: AuthService, private api: ApiService) {
        this.toggleSearch = new Subject();
        this.selectObject = new Subject();
    }

    doSearch(term: string,
             types: Array<string>,
             contextualFilter?: {},
             page?: number,
             pageSize?: number,
             additionalFilters?: {}): Observable<HttpResponse<any>> {
        const searchParams = this.getParams(term, types, contextualFilter, page, pageSize, additionalFilters);

        return this.http.get(environment.serviceSettings.url.search, {
            observe: 'response',
            headers: this.api.getHeaders('get'),
            params: searchParams
        });
    }

    getRecentSearches(page: number, pageSize = 15): Observable<HttpResponse<any>> {
        const searchParams = this.getParams(null, null, null, page, pageSize);

        return this.http.get(environment.serviceSettings.url.recentSearches, {
            observe: 'response',
            headers: this.api.getHeaders('get'),
            params: searchParams
        });
    }

    getParams(term: string = '',
              types: Array<string> = [],
              contextualFilter?: {},
              page?: number,
              pageSize: number = 9,
              additionalFilters?: {}): HttpParams {

        let search = new HttpParams();

        // Handle Pagination
        if (page) {
            if (page > 0) {
                search = search.set('CurrentPage', '' + page);
            }
            else {
                search = search.set('CurrentPage', '1');
            }
            search = search.set('PageSize', '' + pageSize);
        }

        // Handle adding text
        // Forcefully add text param
        search = search.set('text', term);


        // if there's contextual filter items applied, add those to the search query params too
        if (contextualFilter) {
            const keys = Object.keys(contextualFilter);

            for (let k = 0; k < keys.length; k++) {
                search = search.set(keys[k], contextualFilter[keys[k]]);
            }
        }

        // if there's additional filters added, set them up as search params
        if (additionalFilters) {
            const keys = Object.keys(additionalFilters);

            for (let k = 0; k < keys.length; k++) {
                search = search.set(keys[k], additionalFilters[keys[k]]);
            }
        }

        // Check the types specified for the search
        if (types && types.length > 0) {
            let typesString = '';
            for (let x = 0; x < types.length; x++) {
                typesString += types[x];
                if (x != types.length - 1) {
                    typesString += ',';
                }
            }
            search = search.set('tags', typesString);
        }
        return search;
    }

    toggleSearchRemotely(categories: Array<string>,
                         text: string,
                         selectMode: boolean = false,
                         strictSelectionValidation: {} = {'enable':false},
                         context: {} = null,
                         heading: {} = null,
                         filters: {} = null) {

        const searchOptions = {
            'categories': categories,
            'text': text,
            'strictSelectionValidation': strictSelectionValidation
        };
        if (selectMode) {
            searchOptions['selectMode'] = selectMode;
        }
        if (context) {
            searchOptions['contextualSearch'] = context;
        }
        if (heading) {
            searchOptions['heading'] = heading;
        }
        if (filters) {
            searchOptions['filters'] = filters;
        }

        this.toggleSearch.next(searchOptions);
    }

    selectNewObject(object: any) {
        this.selectObject.next(object);
    }

    subscribeToSearchRemote() {
        return this.toggleSearch.asObservable();
    }

    subscribeToSelect() {
        return this.selectObject.asObservable();
    }

}
