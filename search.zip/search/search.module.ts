import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';



import {SharedModule} from '../shared/shared.module';
import { CustomerModule } from '../customer/customer.module'
import { VehicleModule } from '../vehicle/vehicle.module'
import {SearchComponent} from './search/search.component';
import {SearchService} from './search.service';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        CustomerModule,
        VehicleModule
    ],
    providers: [SearchService],
    declarations: [SearchComponent],
    exports: [SearchComponent]
})
export class SearchModule {
}
