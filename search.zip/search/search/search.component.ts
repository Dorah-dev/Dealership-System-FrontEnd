import * as moment from "moment";

import { AfterContentInit, Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';

import { CustomValidators } from 'ng2-validation';

import { Router } from '@angular/router';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';

import { Subscription } from 'rxjs/Subscription';
import { environment } from '../../../environments/environment';

import { NgxPermissionsService } from 'ngx-permissions';
import { ApiService } from '../../core/api/api.service';
import { SearchService } from '../search.service';
import { AlertService } from '../../shared/alert/alert.service';

import { DateTimeSelectorComponent } from '../../shared/date-time-selector/date-time-selector.component';
import { ConfirmComponent } from '../../shared/alert/confirm/confirm.component';
import { ValueConfirmComponent } from '../../shared/alert/value-confirm/value-confirm.component';

import { Customer } from '../../customer/model/customer';
import { Vehicle } from '../../vehicle/model/vehicle';
import { VehicleStock } from '../../sales/model/vehicleStock';
import { Dealership } from '../../dealership/model/dealership';
import { ServiceBooking } from '../../service/model/servicebooking';
import { Observable, Subject } from 'rxjs';
import { AuthService } from '../../auth/services/auth.service';
import { LocalStorageService, StorageKeyArea, StorageKeyType } from '../../core/local-storage/local-storage.service';


@Component({
    selector: 'app-search',
    templateUrl: './search.component.html',
    styleUrls: ['./search.component.scss'],
    animations: [
        trigger(
            'fadeAnimation', [
                state('true', style({ opacity: 1 })),
                state('false', style({ opacity: 0 })),
                transition('* => *', animate('.4s'))
            ]
        )
    ],
})
export class SearchComponent implements OnInit, OnDestroy, AfterContentInit {
    @ViewChild('searchDesktop') search1;
    @ViewChild('searchMobile') search2;

    @Input() searchOptions: any;

    vehicle: Vehicle;
    stockVehicle: VehicleStock;
    customer: Customer;

    @Output() close: EventEmitter<any> = new EventEmitter();

    isVisible: boolean;
    searchCtrl: FormControl;
    searchSubscription: Subscription;
    searchRequest: Subscription;
    selectMode: boolean;
    strictSelectionValidation: {};
    context: {};
    filters: {};
    selectionValidation: {};

    customerCheck: boolean;
    vehicleCheck: boolean;

    searchCategories: Array<{}>;
    selectedCategories: Array<{}>;
    recentSearches: Array<{}>;
    results: {};
    resultKeys: Array<string>;
    categoryTitles: {};

    searching: boolean;
    searched: boolean;
    environment: any;

    currentPage: number;
    totalPages: number;
    totalElements: number;
    pageSize: number;
    newSearch: boolean;

    //variables for in search creations
    addMode: boolean;
    editMode: boolean;
    addType: string;

    appointmentMode: boolean;
    appointmentCustomerId: number;

    mainHeading: string;
    subHeading: string;
    iconHeading: string;

    allowNavigation: boolean;

    dealershipChange: Observable<Dealership>;
    dealershipChangeSub: Subscription;
    currentDealership: Dealership;

    vehicleParams: Array<string> = ["MMCode", "Ownerships", "ServiceCampaigns", "TFSLead", "Models", "Series", "Makes", "Customers",
        "BodyStyles", "BodyStyleFiles", "Files"];
    addLabels: any = {
        'private': "SEARCH.ADD.PRIVATE",
        'company': "SEARCH.ADD.COMPANY",
        'customer': "SEARCH.ADD.CUSTOMER",
        'vehicle': "SEARCH.ADD.VEHICLE"
    };

    constructor(private search: SearchService, private router: Router, private permissionService: NgxPermissionsService,
        private modalService: NgbModal, private api: ApiService, private auth: AuthService,
        private translate: TranslateService, private lss: LocalStorageService, private alert: AlertService) {
        this.searching = false;
        this.searched = false;
        this.isVisible = false;
        this.pageSize = 9;
        this.environment = environment;
        this.currentPage = 1;
        this.selectMode = false;
        this.strictSelectionValidation = { 'enable': false };
        this.customerCheck = false;
        this.vehicleCheck = false;
        this.appointmentMode = false;
        this.categoryTitles = {
            'private': 'SEARCH.ENTITIES.GUEST',
            'company': 'SEARCH.ENTITIES.COMPANY',
            'customer': 'SEARCH.ENTITIES.CUSTOMER',
            'vehicle': 'SEARCH.ENTITIES.VEHICLE',
            'relationship': 'SEARCH.ENTITIES.RELATIONSHIP',
            'ownership': 'SEARCH.ENTITIES.OWNERSHIP',
            'stock': 'SEARCH.ENTITIES.STOCK'
        };
        this.newSearch = true;
        this.allowNavigation = false;
        this.addMode = false;
        this.editMode = false;
        this.addType = "";
        this.filters = {};
    }

    ngOnDestroy() {
        this.searchSubscription.unsubscribe();
    }

    ngOnInit() {
        this.searchCtrl = new FormControl();
        this.searchCategories = [
            { 'Id': 1, 'Name': 'Guests', 'Value': 'private' },
            { 'Id': 2, 'Name': 'Companies', 'Value': 'company' },
            { 'Id': 3, 'Name': 'Vehicles', 'Value': 'vehicle' },
            { 'Id': 4, 'Name': 'Stock', 'Value': 'stock' }
        ];
        this.selectedCategories = [
            { 'Id': 1, 'Name': 'Guests', 'Value': 'private' },
            { 'Id': 2, 'Name': 'Companies', 'Value': 'company' },
            { 'Id': 3, 'Name': 'Vehicles', 'Value': 'vehicle' }
        ];

        this.dealershipChange = this.auth.subscribeToDealershipChange();

        this.searchSubscription =
            this.searchCtrl.valueChanges.debounceTime(this.environment.DEBOUNCE_TIME).subscribe((value) => {
                this.newSearch = true;
                this.currentPage = 1;
                this.doSearch(value, this.currentPage, null, null, this.filters);
            });
        this.recentSearches = [];
        this.search.getRecentSearches(1)
            .subscribe((value) => {
                this.recentSearches = value.body;
            });

        if (this.searchOptions) {
            this.setSearchOptions();
        }

        let permissions = this.permissionService.getPermissions();
        if (permissions) {
            //USE TO IMPLEMENT PERMISSIONS
            // if (permissions[""]) {
            //     this.allowNavigation = true;
            // } else {
            //     this.allowNavigation = false;
            // }
        }

        this.dealershipChangeSub = this.dealershipChange.subscribe(dealer => {
            if (dealer.Id > 0) {
                this.currentDealership = dealer;
                this.filters['dealerId'] = this.currentDealership.Id;
            }

        });
    }

    ngAfterContentInit() {
        if (this.search1.nativeElement.offsetParent !== null) {
            this.search1.nativeElement.focus();
        } else if (this.search2.nativeElement.offsetParent !== null) {
            this.search2.nativeElement.focus();
        }
        this.isVisible = true;
    }

    setSearchOptions() {
        let newTags = new Array();
        this.selectMode = this.searchOptions['selectMode'];
        this.strictSelectionValidation = this.searchOptions['strictSelectionValidation'];
        for (let c = 0; c < this.searchOptions['categories'].length; c++) {
            for (let y = 0; y < this.searchCategories.length; y++) {
                if (this.searchOptions['categories'][c] === this.searchCategories[y]['Value']) {
                    if (this.selectMode) {
                        this.searchCategories[y]['readonly'] = true;
                    }
                    newTags.push(this.searchCategories[y]);
                    break;
                }
            }
        }
        this.selectedCategories = newTags;
        if (this.selectMode) {
            this.searchCategories = newTags;
        }

        if (this.searchOptions['filters']) {
            let params = this.searchOptions['filters'];
            this.filters = params;
        } else {
            if (this.currentDealership && this.currentDealership.Id > 0) {
                this.filters = {
                    'dealerId': this.currentDealership.Id
                };
            }
        }

        if (this.searchOptions['contextualSearch']) {
            let params = this.searchOptions['contextualSearch'];
            this.context = params;
            this.doSearch('', 1, params['tags'], params['context'], this.filters);
        }
        else if (this.searchOptions['text'] && this.searchOptions['text'].length > 0) {
            this.searchCtrl.setValue(this.searchOptions['text']);
        }


        if (this.searchOptions['heading']) {
            this.mainHeading = this.searchOptions['heading'].main;
            this.subHeading = this.searchOptions['heading'].sub;
            this.iconHeading = this.searchOptions['heading'].icon;
        }
    }

    doSearch(value: string,
        page: number,
        customTags: Array<string> = null,
        contextualFilter: {} = null,
        additionalFilters: {} = null) {
        this.addMode = false;
        this.editMode = false;
        let newValue = value.trim();
        if (newValue.length >= 3 || contextualFilter) {
            if (newValue.length >= 3) {
                this.context = null;
            }
            this.results = {};
            this.resultKeys = [];
            this.searching = true;
            this.searched = false;

            const tags = [];
            if (customTags) {
                for (let x = 0; x < customTags.length; x++) {
                    tags.push(customTags[x]);
                }
            }
            else {
                for (let x = 0; x < this.selectedCategories.length; x++) {
                    tags.push(this.selectedCategories[x]['Value']);
                }
            }

            if (this.newSearch) {
                let typesString = '';
                for (let x = 0; x < tags.length; x++) {
                    typesString += tags[x];
                    if (x != tags.length - 1) {
                        typesString += ',';
                    }
                }
                this.recentSearches.push({ 'Term': newValue, Type: 'Search', 'Date': new Date(), Tags: typesString });
            }
            if (this.searchRequest) {
                this.searchRequest.unsubscribe();
            }

            this.searchRequest =
                this.search.doSearch(newValue, tags, contextualFilter, page, this.pageSize, additionalFilters)
                    .flatMap((response) => {
                        this.totalPages = parseInt(response.headers.get('X-Pages'), 10);
                        this.totalElements = parseInt(response.headers.get('X-Count'), 10);
                        return response.body;
                    }).map(data => {
                        return data;
                    }).filter(data => {
                        return !data['Deleted'];
                    }).take(100)
                    .subscribe((data) => {
                        if (!this.results[data['EntityType']]) {
                            this.results[data['EntityType']] = [];
                        }
                        this.results[data['EntityType']].push(data);
                    },
                        (error) => {
                            this.searching = false;
                        },
                        () => {
                            this.searching = false;
                            this.newSearch = false;
                            this.searched = true;
                            this.resultKeys = Object.keys(this.results);
                        });
        }
    }

    clearHistory() {
        this.recentSearches = [];
    }

    hasCategory(category: string): boolean {
        for (let x = 0; x < this.selectedCategories.length; x++) {
            if (this.selectedCategories[x]['Value'] === category) {
                return true;
            }
        }
        return false;
    }

    changePage(page: any) {
        this.currentPage = page.page;
        if (this.context) {
            this.doSearch('',
                this.currentPage,
                this.context['tags'],
                this.context['context'],
                this.filters);
        }
        else {
            this.doSearch(
                this.searchCtrl.value,
                this.currentPage,
                null,
                null,
                this.filters);
        }
    }

    searchItem(item: string, tags: string) {
        if (!this.selectMode) {
            const newTags = [];
            const tagArray = tags.split(',');

            for (let x = 0; x < tagArray.length; x++) {
                for (let y = 0; y < this.searchCategories.length; y++) {
                    if (tagArray[x] === this.searchCategories[y]['Value']) {
                        newTags.push(this.searchCategories[y]);
                        break;
                    }
                }
            }
            this.selectedCategories = newTags;
            this.searchCtrl.setValue(item);
        }
    }

    selectItem(object: {}) {
        if (object['EntityType'] === 'private' || object['EntityType'] === 'company' || object['EntityType'] === 'relationship') {
            this.searching = true;
            //GET CUSTOMER OBJECT
            this.api.fetch('Customers', object['Id'], null).subscribe(
                data => {
                    this.searching = false;

                    const newCustomer = new Customer();
                    newCustomer.fromJSON(data.body);
                    this.customer = newCustomer;

                    let type: string;

                    if (this.strictSelectionValidation['enable']) {
                        // Check if data is incomplete
                        let incompletePrivateName: boolean;
                        let incompleteCompanyName: boolean;

                        if (this.customer.IsIndividual) {
                            type = 'private';
                            if (this.customer.FirstName == null || this.customer.Surname == null) {
                                incompletePrivateName = true;
                            }
                            else {
                                incompletePrivateName = false;
                            }
                        }
                        else if (this.customer.IsCompany) {
                            type = 'company';
                            if (this.customer.CompanyName == null) {
                                incompleteCompanyName = true;
                            }
                            else {
                                incompleteCompanyName = false;
                            }
                        }
                        this.customerCheck = (this.customer.IsIndividual && (this.customer.CellNo == null || this.customer.CellNo.length === 0)) || (this.customer.IsCompany && (this.customer.BusinessNo == null || this.customer.BusinessNo.length === 0))
                            || (this.customer.IsIndividual && incompletePrivateName) || (this.customer.IsCompany && incompleteCompanyName);
                    }

                    if (this.customerCheck) {
                        this.addObject(type, true, true);
                    }
                    // Normal select if data is complete
                    else {
                        this.selectObject(newCustomer);
                    }
                },
                error => {

                }
            );
        }
        else if (object['EntityType'] === 'vehicle') {
            this.searching = true;

            //GET VEHICLE OBJECT
            this.api.fetch('Vehicle', object['Id'], null, this.vehicleParams).subscribe(
                data => {
                    this.searching = false;

                    const newVehicle = new Vehicle();
                    newVehicle.fromJSON(data.body);
                    this.vehicle = newVehicle;

                    if (this.strictSelectionValidation['enable']) {
                        // Check if data is incomplete
                        this.vehicleCheck = this.vehicle.ODOMeterReading === 0 || this.vehicle.RegistrationNumber == null
                            || this.vehicle.Vin == null || this.vehicle.TransmissionId == null;
                    }

                    if (this.vehicleCheck) {
                        this.addObject('vehicle', true, true);
                    }
                    // Normal select if data is complete
                    else {
                        if (this.strictSelectionValidation['confirm']) {
                            if (this.strictSelectionValidation['confirm'] === 'ODOMeterReading') {
                                if (moment(newVehicle.DateModified).format('YYYY-MM-DD') != moment().format('YYYY-MM-DD') && moment(newVehicle.DateCreated).format('YYYY-MM-DD') != moment().format('YYYY-MM-DD')) {
                                    this.openKMConfirmModal(newVehicle).subscribe(km => {

                                        if (km) {
                                            if (km > -1) {
                                                newVehicle.ODOMeterReading = km;
                                                this.updateVehicle(newVehicle).subscribe(data => {
                                                    if (this.appointmentMode) {

                                                        this.checkIfVehicleNotAlreadyBooked(this.appointmentCustomerId, data['Id']);

                                                    } else {
                                                        this.selectObject(data);
                                                    }
                                                });
                                            }
                                            else {
                                                if (this.appointmentMode) {
                                                    this.checkIfVehicleNotAlreadyBooked(this.appointmentCustomerId, data['Id']);
                                                } else {
                                                    this.selectObject(data);
                                                }
                                            }

                                        }

                                    })

                                }
                                else {
                                    if (this.appointmentMode) {
                                        this.checkIfVehicleNotAlreadyBooked(this.appointmentCustomerId, object['Id']);
                                    } else {
                                        this.selectObject(newVehicle);
                                    }
                                }
                            }
                        }
                        else {
                            if (this.appointmentMode) {
                                this.checkIfVehicleNotAlreadyBooked(this.appointmentCustomerId, object['Id']);
                            } else {
                                this.selectObject(newVehicle);
                            }
                        }
                    }
                },
                error => {

                }
            );

        } else if (object['EntityType'] === 'stock') {
            this.searching = true;
            //GET VEHICLE OBJECT
            this.api.fetch('VehicleStock', object['Id'], null, this.vehicleParams).subscribe(
                data => {
                    this.searching = false;

                    const vehicleStock = new VehicleStock();
                    vehicleStock.fromJSON(data.body);
                    this.stockVehicle = vehicleStock;

                    this.selectObject(vehicleStock);
                },
                error => {

                }
            );
        }
    }

    openKMConfirmModal(vehicle: Vehicle): Observable<number> {
        let subject: Subject<number> = new Subject();
        if (moment(vehicle.DateModified).format('YYYY-MM-DD') != moment().format('YYYY-MM-DD') && moment(vehicle.DateCreated).format('YYYY-MM-DD') != moment().format('YYYY-MM-DD')) {
            this.translate.get('SERVICE.APPOINTMENT.CONFIRM.ODOMETERREADING.TITLE', { 'vehicle': vehicle.VehicleDescription })
                .subscribe((res1: string) => {
                    this.translate.get('SERVICE.APPOINTMENT.CONFIRM.ODOMETERREADING.ERROR', { 'min': vehicle.ODOMeterReading })
                        .subscribe((res2: string) => {
                            const options: NgbModalOptions = {};
                            const modalRef = this.modalService.open(ValueConfirmComponent, options);

                            modalRef.componentInstance.titleText = res1;
                            modalRef.componentInstance.descriptionText = 'SERVICE.APPOINTMENT.CONFIRM.ODOMETERREADING.DESCRIPTION';
                            modalRef.componentInstance.inputLabel = 'VEHICLE.SINGLE_VIEW.LABELS.ODO';
                            modalRef.componentInstance.inputValue = vehicle.ODOMeterReading;
                            modalRef.componentInstance.inputError = res2;
                            modalRef.componentInstance.validator = [Validators.required, CustomValidators.min(vehicle.ODOMeterReading)];
                            modalRef.result
                                .then(close => {
                                    subject.next(close);
                                }, dismissed => {
                                    subject.next(null);
                                });
                        });
                });
        }
        else {
            setTimeout(function() {
                subject.next(-1);
            }, 100);
        }

        return subject.asObservable();
    }

    openItem(type: string, id: number) {
        if (type === 'private' || type === 'company') {
            this.router.navigate(['guest/singleview/' + id + '/details']);
        }
        else if (type === 'vehicle') {
            this.router.navigate(['/vehicle/singleview/' + id + '/details']);
        }
        this.closeSearch();
    }

    fakeSearchResult(obj: any, type: string) {
        let searchObj = {
            'EntityType': type,
            'Id': obj.Id,
        };

        if (type === 'private' || type === 'company') {
            searchObj['ImageText'] = obj.IsCompany ? obj.CompanyName[0].toUpperCase() : obj.FirstName[0].toUpperCase() + obj.Surname[0].toUpperCase();
            searchObj['Line1'] = obj.IsCompany ? obj.CompanyName : obj.FirstName + obj.Surname;
            searchObj['Line2'] = obj.CellNo;
            searchObj['Line3'] = obj.EmailAddress;
        }
        else if (type === 'vehicle') {
            searchObj['ImageText'] = obj.RegistrationNumber ? obj.RegistrationNumber.slice(0, 3) : 'VEH';
            searchObj['Line1'] = obj.Vin;
            searchObj['Line2'] = obj.RegistrationNumber;
            searchObj['Line3'] = obj.ODOMeterReading;
        }
        let arr = [searchObj];
        this.results[type] = arr;
        this.resultKeys = Object.keys(this.results);
        this.currentPage = 1;
        this.totalPages = 1;
        this.totalElements = 1;
    }

    addObject(type: string, edit: boolean, showMessage: boolean = false) {
        if (type === 'customer') {
            if (this.hasCategory('private') && this.hasCategory('company')) {
                type = 'customer';
            }
            else if (this.hasCategory('private')) {
                type = 'private';
            }
            else if (this.hasCategory('company')) {
                type = 'company';
            }
        }


        this.addType = type;
        if (edit) {
            if (showMessage) {
                this.translate.get("SEARCH.NOTIFICATIONS.MISSING_DETAILS", { 'type': this.addType })
                    .subscribe((res1: string) => {
                        this.alert.componentInfo(res1, true);

                        this.editMode = true;
                    });
            } else {
                this.editMode = true;
            }
        }
        else {
            this.addMode = true;
        }
    }

    clearAdd() {
        this.editMode = false;
        this.addMode = false;
        this.addType = "";
        this.customer = null;
        this.vehicle = null;
        this.stockVehicle = null;
    }

    selectObject(obj: any) {
        this.search.selectNewObject(obj);
        this.close.emit();

    }

    closeSearch() {
        if (this.selectMode) {
            this.search.selectNewObject(null);
        }
        this.close.emit();
    }

    saveCustomer(customer: Customer) {
        this.addMode = false;
        this.editMode = false;
        this.searching = true;
        if (customer.Id === 0) {
            this.api.create('Customers', customer)
                .subscribe(
                    data => {
                        this.searching = false;
                        const customer = new Customer();
                        customer.fromJSON(data.body);
                        this.fakeSearchResult(customer, customer.IsCompany ? 'company' : 'private');
                    },
                    error => {
                        this.searching = false;
                    }
                );
        }
        else if (customer.Id > 0) {
            this.api.update('Customers/' + customer.Id, customer)
                .subscribe(
                    data => {
                        this.searching = false;
                        const customer = new Customer();
                        customer.fromJSON(data.body);

                        this.search.selectNewObject(customer);
                        this.close.emit();
                    },
                    error => {
                        this.searching = false;
                    }
                );
        }
    }

    saveVehicle(vehicle: Vehicle) {
        this.addMode = false;
        this.searching = true;
        if (vehicle.Id === 0) {
            if (this.appointmentCustomerId && this.appointmentCustomerId > 0) {
                vehicle.CustomerId = this.appointmentCustomerId;
            }
            this.api.create('Vehicle', vehicle)
                .subscribe(
                    data => {
                        this.searching = false;
                        const vehicle = new Vehicle();
                        vehicle.fromJSON(data.body);

                        if (!this.strictSelectionValidation['enable']) {
                            this.search.selectNewObject(vehicle);
                            this.close.emit();
                        } else {
                            this.fakeSearchResult(vehicle, 'vehicle');
                        }
                    },
                    error => {
                        this.searching = false;
                    }
                );
        }
        else if (vehicle.Id > 0) {
            this.api.update('Vehicle/' + vehicle.Id, vehicle)
                .subscribe(
                    data => {
                        this.searching = false;
                        const vehicle = new Vehicle();
                        vehicle.fromJSON(data.body);

                        if (this.appointmentMode) {
                            this.openDateTimeModal(this.appointmentCustomerId, vehicle.Id);
                        } else {
                            this.search.selectNewObject(vehicle);
                            this.close.emit();
                        }
                    },
                    error => {

                    }
                );
        }
    }

    updateVehicle(vehicle: Vehicle): Observable<Vehicle> {
        this.searching = true;
        let subject: Subject<Vehicle> = new Subject();
        this.api.update('Vehicle/' + vehicle.Id, vehicle)
            .subscribe(
                data => {
                    this.searching = false;
                    const vehicle = new Vehicle();
                    vehicle.fromJSON(data.body);
                    subject.next(vehicle);
                },
                error => {
                    subject.next(null);
                }
            );
        return subject.asObservable();
    }

    navToAppointment(type: string, id: number) {
        //GET VEHICLE ID FROM API:
        this.appointmentMode = true;
        if (type === 'private' || type === 'company') {
            this.searching = true;
            let filter = { 'CustomerId': id, 'Deleted': false, 'Active': true };
            //Get vehicle object
            this.appointmentCustomerId = id;
            this.api.list('Vehicle', 0, 0, null, false, null, filter, this.vehicleParams).subscribe(
                data => {
                    if (data.body && data.body.length === 1) {
                        this.searching = false;
                        let vehicle: Vehicle = data.body[0];
                        let vehicleCheck = vehicle.ODOMeterReading === 0 || vehicle.RegistrationNumber == null
                            || vehicle.Vin == null || vehicle.TransmissionId == null;
                        if (vehicleCheck) {
                            this.vehicle = vehicle;
                            this.addObject('vehicle', true, true);
                        }
                        else {
                            this.openKMConfirmModal(vehicle).subscribe(km => {
                                if (km) {
                                    if (km > -1) {
                                        vehicle.ODOMeterReading = km;
                                        this.updateVehicle(vehicle).subscribe(data => {

                                            this.checkIfVehicleNotAlreadyBooked(id, vehicle.Id);

                                        });
                                    } else {
                                        this.checkIfVehicleNotAlreadyBooked(id, vehicle.Id);
                                    }

                                }

                            })
                        }
                    }
                    else {
                        if (!data.body || data.body.length === 0) {
                            this.searchCtrl.setValue("");
                        }
                        this.searching = false;
                        this.selectMode = true;

                        let context = { 'tags': ['vehicle'], 'context': { 'customerId': id } };
                        let headings = {
                            'main': 'SEARCH.HEADINGS.VEHICLE.MAIN',
                            'sub': 'SEARCH.HEADINGS.VEHICLE.SUB_BOOKING',
                            'icon': 'vehicle'
                        };
                        let searchOptions = {
                            'categories': ['vehicle'],
                            'text': '',
                            'selectMode': true,
                            'strictSelectionValidation': { 'enable': true, 'confirm': 'ODOMeterReading' },
                            'contextualSearch': context,
                            'heading': headings
                        };
                        this.searchOptions = searchOptions;
                        this.setSearchOptions();
                    }
                },
                error => {
                    this.searching = false;
                }
            );
        }

        //GET CUSTOMER ID FROM API:
        else if (type === 'vehicle') {
            this.searching = true;
            //Get vehicle object
            this.api.fetch('Vehicle', id, null, this.vehicleParams).subscribe(
                data => {
                    this.searching = false;

                    let newVehicle = new Vehicle();
                    newVehicle.fromJSON(data.body);
                    this.appointmentCustomerId = newVehicle.CustomerId;

                    //get customerId from vehicles
                    if (newVehicle && newVehicle.CustomerId) {
                        // call modal function to show date picker
                        let vehicleCheck = newVehicle.ODOMeterReading === 0 || newVehicle.RegistrationNumber == null
                            || newVehicle.Vin == null || newVehicle.TransmissionId == null;
                        if (vehicleCheck) {
                            this.vehicle = newVehicle;
                            this.addObject('vehicle', true, true);
                        }
                        else {
                            this.openKMConfirmModal(newVehicle).subscribe(km => {
                                if (km) {
                                    if (km > -1) {
                                        newVehicle.ODOMeterReading = km;
                                        this.updateVehicle(newVehicle).subscribe(data => {

                                            this.checkIfVehicleNotAlreadyBooked(newVehicle.CustomerId, id);

                                        });
                                    }
                                    else {
                                        this.checkIfVehicleNotAlreadyBooked(newVehicle.CustomerId, id);
                                    }

                                }

                            })
                        }

                    } else {
                        this.searching = false;
                    }
                },
                error => {
                    this.searching = false;
                }
            );
        }
    }

    navToNewLead(type: string, id: number) {
        if (type === 'private' || type === 'company') {
            this.router.navigate(['/sales/lead/add/', id]);
        }
        else if (type === 'vehicle') {
            this.searching = true;
            this.api.fetch('Vehicle', id, null, null).subscribe(
                data => {
                    this.searching = false;

                    const newVehicle = new Vehicle();
                    newVehicle.fromJSON(data.body);
                    this.lss.store(StorageKeyArea.LEAD_ADD, StorageKeyType.OPPORTUNITY_TRADE_IN, JSON.stringify([newVehicle]));
                    this.router.navigate(['/sales/lead/add/', newVehicle.CustomerId]);
                },
                error => {
                    this.searching = false;
                }
            );

        }
        this.closeSearch();
    }

    checkIfVehicleNotAlreadyBooked(customerId: number, vehicleId: number) {
        let subject: Subject<ServiceBooking> = new Subject();

        this.searching = true;

        let filter = {
            'CustomerId': customerId,
            'VehicleId': vehicleId,
            'IsCompleted': false,
            'Deleted': false,
            'Active': true,
            'DateCancelledIsNull': true
        };
        this.api.list('ServiceBookings', null, null, null, false, null, filter, null).subscribe(
            data => {
                this.searching = false;
                if (data.body && data.body.length > 0) {
                    let serviceBooking = new ServiceBooking();
                    serviceBooking.fromJSON(data.body[0]);
                    serviceBooking.convertDatesToLocal();

                    // there is already a booking
                    const options: NgbModalOptions = {
                        size: 'lg'
                    };

                    const modalRef = this.modalService.open(ConfirmComponent, options);

                    modalRef.componentInstance.titleText = 'SERVICE.NEW_APPOINTMENT.CONFIRM.TEXT';
                    modalRef.componentInstance.mainText = 'SERVICE.NEW_APPOINTMENT.CONFIRM.MAIN_TEXT';

                    // translate all the labels first before showing the modal
                    let vehicleTranslate = this.translate.instant('SERVICE.NEW_APPOINTMENT.CONFIRM.VEH_TEXT');
                    let dateTranslate = this.translate.instant('SERVICE.NEW_APPOINTMENT.CONFIRM.DATE_TEXT');
                    let referenceTranslate = this.translate.instant('SERVICE.NEW_APPOINTMENT.CONFIRM.REF_NO_TEXT');
                    let confirmTranslate = this.translate.instant('SERVICE.NEW_APPOINTMENT.CONFIRM.CONFIRM_TEXT');

                    let bookingDate = serviceBooking.DateArriveEstimate.getFullYear() + '-' + ("0" + (serviceBooking.DateArriveEstimate.getMonth() + 1)).slice(-2) + '-' + ("0" + serviceBooking.DateArriveEstimate.getDate()).slice(-2)
                        + ', ' + ("0" + serviceBooking.DateArriveEstimate.getHours()).slice(-2) + ':' + ("0" + serviceBooking.DateArriveEstimate.getMinutes()).slice(-2);

                    let mainHtml = '<div>' + dateTranslate + ' ' + bookingDate + '</div></br> ' +
                                '<div>' + referenceTranslate + ' ' + serviceBooking.Id + '</div></br> ' +
                                '<div>' + confirmTranslate + '</div>';

                    modalRef.componentInstance.mainHtml = mainHtml;

                    modalRef.result
                        .then(close => {
                            this.router.navigate(['service/appointment/' + serviceBooking.Id]);
                            this.closeSearch();
                        }, dismissed => {

                        });
                } else {
                    this.openDateTimeModal(customerId, vehicleId);
                }
            },
            error => {
                // ??
                this.searching = false;
            }
        );
    }

    openDateTimeModal(customerId: number, vehicleId: number) {
        const options: NgbModalOptions = {};
        let modalRef = this.modalService.open(DateTimeSelectorComponent, options);

        modalRef.componentInstance.titleText = 'Select a booking date & time';
        modalRef.componentInstance.showTimeSelector = true;
        let minDate = new Date();
        minDate.setHours(0, 0, 0, 0);
        modalRef.componentInstance.minDate = minDate;

        modalRef.result.then(dismissed => {
            // redirect to appointments, dismissed has the date time in format: yyyyMMdd-hh:mm
            this.router.navigate(['./service/newappointment/' + customerId + '/' + vehicleId + '/' + dismissed]);
            this.closeSearch();
        }, closed => {
            // cancelled selecting booking, so don't redirect
        });
    }

}
