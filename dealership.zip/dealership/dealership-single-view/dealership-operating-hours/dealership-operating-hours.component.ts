import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealership-operating-hours',
  templateUrl: './dealership-operating-hours.component.html',
  styleUrls: ['./dealership-operating-hours.component.scss']
})
export class DealershipOperatingHoursComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
