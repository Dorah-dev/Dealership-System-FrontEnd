import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealershipOperatingHoursComponent } from './dealership-operating-hours.component';

describe('DealershipOperatingHoursComponent', () => {
  let component: DealershipOperatingHoursComponent;
  let fixture: ComponentFixture<DealershipOperatingHoursComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealershipOperatingHoursComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealershipOperatingHoursComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
