import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealershipSettingsComponent } from './dealership-settings.component';

describe('DealershipSettingsComponent', () => {
  let component: DealershipSettingsComponent;
  let fixture: ComponentFixture<DealershipSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealershipSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealershipSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
