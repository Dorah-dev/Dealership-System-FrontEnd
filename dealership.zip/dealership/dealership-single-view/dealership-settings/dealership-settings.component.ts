import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealership-settings',
  templateUrl: './dealership-settings.component.html',
  styleUrls: ['./dealership-settings.component.scss']
})
export class DealershipSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
