import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealershipCalendarComponent } from './dealership-calendar.component';

describe('DealershipCalendarComponent', () => {
  let component: DealershipCalendarComponent;
  let fixture: ComponentFixture<DealershipCalendarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealershipCalendarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealershipCalendarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
