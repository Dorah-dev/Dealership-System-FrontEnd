import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealership-calendar',
  templateUrl: './dealership-calendar.component.html',
  styleUrls: ['./dealership-calendar.component.scss']
})
export class DealershipCalendarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
