import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ApiService} from '../../../core/api/api.service';
import {NgxPermissionsService} from 'ngx-permissions';
import {AuthService} from '../../../auth/services/auth.service';
import {Dealership} from '../../model/dealership';
import {Subject} from 'rxjs/Subject';
import {Subscription} from 'rxjs/Subscription';
import {AccountCardType} from '../../../shared/account-card/account-card/account-card.component';

@Component({
    selector: 'app-dealership-single-view',
    templateUrl: './dealership-single-view.component.html',
    styleUrls: ['./dealership-single-view.component.scss']
})
export class DealershipSingleViewComponent implements OnInit {

    loading = false;
    loadDealerId: number;


    limitX = 800;
    limitY = 5;
    threshold = 5;

    menuElements: Array<any>;

    oldX: number;
    oldY: number;
    changeX: number;
    changeY: number;

    dealership: Dealership;
    scrollSub: Subject<string>;
    permissionChangeSub: Subscription;
    permissions: any;

    withParams = [];
    dealershipAccountCardType = AccountCardType.Dealership;

    constructor(private router: Router, private route: ActivatedRoute,
                private api: ApiService, private permissionService: NgxPermissionsService, private auth: AuthService) {
        this.menuElements = [
            {
                title: 'DEALERSHIP.SINGLE_VIEW.TAB.DEALERSHIP_DETAILS',
                mobile: 'DEALERSHIP.SINGLE_VIEW.TAB.DEALERSHIP_DETAILS',
                url: 'details',
                icon: 'tft-icon-customer-2',
                m_icon: 'tft-icon-customer',
                posX: this.genPosition('x'),
                posY: this.genPosition('y')
            },
            {
                title: 'DEALERSHIP.SINGLE_VIEW.TAB.OPERATING_HOURS',
                mobile: 'DEALERSHIP.SINGLE_VIEW.TAB.OPERATING_HOURS',
                url: 'operating-hours',
                icon: 'tft-icon-customer-garage',
                m_icon: 'tft-icon-garage-mobile',
                posX: this.genPosition('x'),
                posY: this.genPosition('y')
            },
            {
                title: 'DEALERSHIP.SINGLE_VIEW.TAB.SETTINGS',
                mobile: 'DEALERSHIP.SINGLE_VIEW.TAB.SETTINGS',
                url: 'settings',
                icon: 'tft-icon-communications',
                m_icon: 'tft-icon-service-customers',
                posX: this.genPosition('x'),
                posY: this.genPosition('y')
            },
            {
                title: 'DEALERSHIP.SINGLE_VIEW.TAB.CALENDER',
                mobile: 'DEALERSHIP.SINGLE_VIEW.TAB.CALENDER',
                url: 'calender',
                icon: 'tft-icon-timeline',
                m_icon: 'tft-icon-timeline-mobile',
                posX: this.genPosition('x'),
                posY: this.genPosition('y')
            }
        ];

        this.oldX = null;
        this.oldY = null;
        this.changeX = 0;
        this.changeY = 0;

        this.dealership = new Dealership();
        this.scrollSub = new Subject();
    }

    ngOnInit() {
        this.updatePermissions();
        this.permissionChangeSub = this.auth.subscribeToPermissionsChange().subscribe(data => {
            this.updatePermissions();
        });


        let dealershipSubscription = this.route.paramMap.subscribe(
            params => {
                let id = params.get('id');
                if (id) {
                    this.loadDealerId = parseInt(id, 10);
                    if (this.loadDealerId > 0) {
                        this.initComponent();
                    }
                }
            }
        );


    }

    initComponent() {
        this.loading = true;

        this.api.fetch('Dealerships', this.loadDealerId, null, this.withParams).subscribe(
            data => {
                let dealer = new Dealership();
                dealer.fromJSON(data.body);
                this.dealership = dealer;
            },
            error => {
                throw new Error('ERROR.GET');
            }
        );
    }

    updatePermissions() {
        this.permissions = this.permissionService.getPermissions();
        // if (this.permissions) {
        //     if (this.permissions["CUSTLACTVW"]) {
                 // this.allowTimelineView = true;
        //     } else {
                 // this.allowTimelineView = false;
        //     }
        // }
    }

    genPosition(axis: string): number {
        if (axis === 'x') {
            return Math.floor(Math.random() * -(this.limitX));
        }
        else {
            return Math.floor(Math.random() * -(this.limitY));
        }
    }

    updateMouseCoordinates(event) {
        if (this.oldX && this.oldY) {
            const changeXpx = this.oldX - event.screenX;
            const changeYpx = this.oldY - event.screenY;
            this.changeX += changeXpx;
            this.changeY += changeYpx;

            if (this.changeX > this.threshold || this.changeX < -(this.threshold)) {
                for (let x = 0; x < this.menuElements.length; x++) {
                    if (this.changeX > this.threshold) {
                        this.menuElements[x].posX += 5;
                    }
                    else {
                        this.menuElements[x].posX -= 5;
                    }

                    if (this.menuElements[x].posX < -(this.limitX)) {
                        this.menuElements[x].posX = -(this.limitX);
                    }
                    else if (this.menuElements[x].posX > 0) {
                        this.menuElements[x].posX = 0;
                    }
                }
                this.changeX = 0;
            }

            if (this.changeY > this.threshold || this.changeY < -(this.threshold)) {
                for (let x = 0; x < this.menuElements.length; x++) {
                    if (this.changeY > this.threshold) {
                        this.menuElements[x].posY++;
                    }
                    else {
                        this.menuElements[x].posY--;
                    }
                    if (this.menuElements[x].posY < -(this.limitY)) {
                        this.menuElements[x].posY = -(this.limitY);
                    }
                    else if (this.menuElements[x].posY > 0) {
                        this.menuElements[x].posY = 0;
                    }
                }
                this.changeY = 0;
            }
        }
        this.oldX = event.screenX;
        this.oldY = event.screenY;
    }

}
