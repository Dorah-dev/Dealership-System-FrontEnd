import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealershipSingleViewComponent } from './dealership-single-view.component';

describe('DealershipSingleViewComponent', () => {
  let component: DealershipSingleViewComponent;
  let fixture: ComponentFixture<DealershipSingleViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealershipSingleViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealershipSingleViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
