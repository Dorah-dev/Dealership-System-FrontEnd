import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealershipTimelineComponent } from './dealership-timeline.component';

describe('DealershipTimelineComponent', () => {
  let component: DealershipTimelineComponent;
  let fixture: ComponentFixture<DealershipTimelineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealershipTimelineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealershipTimelineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
