import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealership-timeline',
  templateUrl: './dealership-timeline.component.html',
  styleUrls: ['./dealership-timeline.component.scss']
})
export class DealershipTimelineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
