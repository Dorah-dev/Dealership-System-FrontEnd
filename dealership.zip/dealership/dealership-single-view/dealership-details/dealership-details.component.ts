import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealership-details',
  templateUrl: './dealership-details.component.html',
  styleUrls: ['./dealership-details.component.scss']
})
export class DealershipDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
