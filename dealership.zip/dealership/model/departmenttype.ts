import { ToyotaModel } from "../../shared/interfaces/toyota-model";
import { Serializable } from "../../shared/interfaces/serializable";

export class DepartmentType extends ToyotaModel implements Serializable {
    /*Default Fields*/
    Id: number;
    DateCreated: Date;
    DateModified: Date;
    Deleted: boolean;
    Active: boolean;
    /* Fields */
    Code: string;
    Name: string;

    constructor(Id: number = 0,
        DateCreated: Date = null,
        DateModified: Date = null,
        Deleted: boolean = false,
        Active: boolean = false,
        Code: string = '',
        Name: string = '') {
        super();
        this.Id = Id;
        this.DateCreated = DateCreated;
        this.DateModified = DateModified;
        this.Deleted = Deleted;
        this.Active = Active;

        this.Code = Code;
        this.Name = Name;
    }

    fromJSON(obj: any) {
        this.Id = obj.Id;
        this.DateCreated = obj.DateCreated;
        this.DateModified = obj.DateModified;
        this.Deleted = obj.Deleted;
        this.Active = obj.Active;

        this.Code = obj.Code;
        this.Name = obj.Name;
    }

    toJSON() {
        return {
          'Id': this.Id,
          'DateCreated': this.DateCreated,
          'DateModified': this.DateModified,
          'Deleted': this.Deleted,
          'Active': this.Active,

          'Code': this.Code,
          'Name': this.Name
        }

    }
}
