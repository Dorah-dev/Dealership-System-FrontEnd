import {ToyotaModel} from '../../shared/interfaces/toyota-model';
import {Serializable} from '../../shared/interfaces/serializable';
import {Country} from '../../shared/lookups/model/country';
import {environment} from '../../../environments/environment';
export class Dealership extends ToyotaModel implements Serializable {

    /**
     * Dealership properties.
     */
    Id: number;
    Name: string;
    DealerCode: string;
    DealerManagementSystemCode: string;
    EmailAddress: string;
    PhoneNumber1: string;
    PhoneNumber2: string;
    SpeedDial: string;
    FaxNumber: string;
    RegisteredName: string;
    RegNumber: string;
    VatNumber: string;
    IsAutomarkDealer: boolean;
    IsRetailDealer: boolean;
    IsVirtualDealer: boolean;
    IsServiceDealer: boolean;
    StreetAddress: string;
    StreetSuburb: string;
    StreetCode: string;
    Postal: string;
    PostalCity: string;
    PostalCode: string;
    AccountGroup: string;
    Latitude: string;
    Longitude: string;
    DealerManagementSystemId: number;
    CountryId: number;
    DealershipCategoryId: number;
    ParentDealerId: number;
    RegionId: number;
    DPName: string;
    DPEmail: string;
    DPPhoneNumber: string;

    SalesManagerName: string;
    SalesManagerEmail: string;
    SalesManagerPhoneNumber: string;

    ServiceManagerName: string;
    ServiceManagerEmail: string;
    ServiceManagerPhoneNumber: string;

    DateCreated: Date;
    DateModified: Date;
    Deleted: boolean;
    Active: boolean;

    DealershipDepartment: Array<any>;
    DealershipComponents: Array<any>;
    DealershipModules: Array<any>;
    DealershipSettings: Array<any>;
    DealershipList: Array<any>;
    DealershipSalesAreas: Array<any>;

    ImageURL: string;

    Country: Country;
    /**
     * Form & List properties to determine how & where dealership properties are displayed.
     */

    formProperties = {
        editable: ['DealershipModules', 'DealershipComponents'], //NO NEED TO EDIT ANYTHING
        form: ['Name', 'DealerCode', 'PhoneNumber1', 'StreetAddress', 'StreetSuburb', 'StreetCode', 'DealershipModules', 'DealershipComponents', 'Latitude', 'Longitude', 'Active'], //properties displayed on the form

        permissions: {},

        formLayout: [ //creating sections in form layout
            {
                'column': 6,
                'panels': [{
                    'id': 1,
                    'fields': ['Name', 'DealerCode', 'PhoneNumber1', 'Active'],
                    'column': '6',
                    'heading': 'DEALERSHIP.LABELS.DEALERSHIP_DETAILS'
                },
                    {

                        'id': 3,
                        'fields': ['StreetAddress', 'StreetSuburb', 'StreetCode', 'Latitude', 'Longitude'],
                        'column': '6',
                        'heading': 'COMMON.LABELS.LOCATION'
                    },
                    {
                        'id': 5,
                        'fields': ['SalesManagerName', 'SalesManagerEmail', 'SalesManagerPhoneNumber'],
                        'column': '6',
                        'heading': 'DEALERSHIP.LABELS.SALES_MANAGER_DETAILS'
                    }
                ]
            }, {
                'column': 6,
                'panels': [
                    {
                        'id': 2,
                        'content': '<h6>Placeholder for Dealership Settings/Configurations</h6>',
                        'column': '6',
                        'heading': 'DEALERSHIP.LABELS.DEALERSHIP_SETTINGS'
                    },
                    {
                        'id': 4,
                        'fields': ['DPName', 'DPEmail', 'DPPhoneNumber'],
                        'column': '6',
                        'heading': 'DEALERSHIP.LABELS.DP_DETAILS'
                    },
                    {
                        'id': 6,
                        'fields': ['ServiceManagerName', 'ServiceManagerEmail', 'ServiceManagerPhoneNumber'],
                        'column': '6',
                        'heading': 'DEALERSHIP.LABELS.SERVICE_MANAGER_DETAILS'
                    },
                    {
                        'id': 8,
                        'fields': ['DealershipComponents'],
                        'column': '6',
                        'heading': 'COMPONENTS.TITLE'
                    }]
            },

        ],
        formTypes: {},
        labels: { //labels on form & list
            'Id': 'COMMON.LABELS.ID',
            'Name': 'COMMON.LABELS.NAME',
            'Active': 'COMMON.LABELS.ACTIVE',
            'DealerCode': 'DEALERSHIP.LABELS.CODE',
            'StreetAddress': 'DEALERSHIP.LABELS.STREET_ADDRESS',
            'StreetSuburb': 'DEALERSHIP.LABELS.STREET_SUBURB',
            'StreetCode': 'DEALERSHIP.LABELS.STREET_CODE',
            'CreatedAt': 'COMMON.LABELS.CREATED',
            'PhoneNumber1': 'COMMON.LABELS.PHONE_NUMBER',
            'Latitude': 'COMMON.LABELS.LATITUDE',
            'Longitude': 'COMMON.LABELS.LONGITUDE',
            'DPName': 'DEALERSHIP.LABELS.DP_NAME',
            'DPPhoneNumber': 'DEALERSHIP.LABELS.DP_PHONE_NUMBER',
            'DPEmail': 'DEALERSHIP.LABELS.DP_EMAIL',
            'SalesManagerName': 'DEALERSHIP.LABELS.SALES_MANAGER_NAME',
            'SalesManagerPhoneNumber': 'DEALERSHIP.LABELS.SALES_MANAGER_PHONE_NUMBER',
            'SalesManagerEmail': 'DEALERSHIP.LABELS.SALES_MANAGER_EMAIL',
            'ServiceManagerName': 'DEALERSHIP.LABELS.SERVICE_MANAGER_NAME',
            'ServiceManagerPhoneNumber': 'DEALERSHIP.LABELS.SERVICE_MANAGER_PHONE_NUMBER',
            'ServiceManagerEmail': 'DEALERSHIP.LABELS.SERVICE_MANAGER_EMAIL'
        },
        list: [{ // properties displayed on the list
            headerCheckboxable: false,
            sortable: false,
            checkboxable: false,
            width: 30,
            resizeable: false,
            canAutoResize: false
        },
            {prop: 'Id', width: 80},
            {prop: 'DealerCode', sortable: false, width: 130},
            {prop: 'Name', sortable: false, width: 210},
            {prop: 'StreetSuburb', width: 130},
            {prop: 'DPName', sortable: false, width: 190},
            {prop: 'PhoneNumber1', sortable: false, width: 130}
        ],

        mobile: [ //properties displayed on the Accordion for mobile view
            {prop: 'Id', header: false},
            {prop: 'DealerCode', header: true},
            {prop: 'Name', header: true},
            {prop: 'DPName', header: true}
        ],
        load: {
            'DealershipComponents': {
                'url': 'modules?with=components,Deleted=false',
                'type': 'tree-multi',
                'keys': ['DealershipModules', 'DealershipComponents'],
                'id': 'Id',
                'display': 'Name',
                'foreign': ['ModuleId', 'ComponentId'],
                'foreignMap': [{
                    'Name': 'ModuleName',
                    'Description': 'ModuleDescription',
                    'Code': 'ModuleCode'
                },
                    {
                        'Name': 'ComponentName',
                        'Description': 'ComponentDescription',
                        'Code': 'ComponentCode'
                    }]
            }
        },
        primaryKey: 'Id', //primary key
        required: [], //fields that requires input
        sortable: ['DealerCode', 'Name', 'StreetSuburb'], //columns that can be sorted on list
        toggleable: true, //allows toggleability
        validation: { //validation on input fields
            validateAs: {},
            maxLength: {},
            minLength: {},
            confirm: []
        }
    };


    constructor(Id: number = 0,
                Name: string = '',
                DealerCode: string = '',
                DealerManagementSystemCode: string = '',
                EmailAddress: string = '',
                PhoneNumber1: string = '',
                PhoneNumber2: string = '',
                SpeedDial: string = '',
                FaxNumber: string = '',
                RegisteredName: string = '',
                RegNumber: string = '',
                VatNumber: string = '',
                IsAutomarkDealer: boolean = false,
                IsRetailDealer: boolean = false,
                IsVirtualDealer: boolean = false,
                IsServiceDealer: boolean = false,
                StreetAddress: string = '',
                StreetSuburb: string = '',
                StreetCode: string = '',
                Postal: string = '',
                PostalCity: string = '',
                PostalCode: string = '',
                AccountGroup: string = '',
                Latitude: string = '',
                Longitude: string = '',
                DealerManagementSystemId: number = 0,
                CountryId: number = 0,
                DealershipCategoryId: number = 0,
                ParentDealerId: number = 0,
                RegionId: number = 0,
                DealershipComponents: Array<any> = [],
                DealershipModules: Array<any> = [],
                DealershipList: Array<any> = [],
                DealershipSalesAreas: Array<any> = [],
                ImageURL: string = '') {
        super();
        this.Id = Id;
        this.Active = true;
        this.Deleted = false;
        this.Name = Name;
        this.DealerCode = DealerCode;
        this.DealerManagementSystemCode = DealerManagementSystemCode;
        this.EmailAddress = EmailAddress;
        this.PhoneNumber1 = PhoneNumber1;
        this.PhoneNumber2 = PhoneNumber2;
        this.SpeedDial = SpeedDial;
        this.FaxNumber = FaxNumber;
        this.RegisteredName = RegisteredName;
        this.RegNumber = RegNumber;
        this.VatNumber = VatNumber;
        this.IsAutomarkDealer = IsAutomarkDealer;
        this.IsRetailDealer = IsRetailDealer;
        this.IsVirtualDealer = IsVirtualDealer;
        this.IsServiceDealer = IsServiceDealer;
        this.StreetAddress = StreetAddress;
        this.StreetSuburb = StreetSuburb;
        this.StreetCode = StreetCode;
        this.Postal = Postal;
        this.PostalCity = PostalCity;
        this.PostalCode = PostalCode;
        this.AccountGroup = AccountGroup;
        this.Latitude = Latitude;
        this.Longitude = Longitude;
        this.DealerManagementSystemId = DealerManagementSystemId;
        this.CountryId = CountryId;
        this.DealershipCategoryId = DealershipCategoryId;
        this.ParentDealerId = ParentDealerId;
        this.RegionId = RegionId;
        this.DPName = '';
        this.DPEmail = '';
        this.DPPhoneNumber = '';
        this.SalesManagerName = '';
        this.SalesManagerEmail = '';
        this.SalesManagerPhoneNumber = '';
        this.ServiceManagerName = '';
        this.ServiceManagerEmail = '';
        this.ServiceManagerPhoneNumber = '';

        this.DealershipComponents = DealershipComponents;
        if (!this.DealershipComponents) {
            this.DealershipComponents = [];
        }
        this.DealershipModules = DealershipModules;
        if (!this.DealershipModules) {
            this.DealershipModules = [];
        }
        this.DealershipList = DealershipList;
        if (!this.DealershipList) {
            this.DealershipList = [];
        }

        this.DealershipSalesAreas = DealershipSalesAreas;
        if (!this.DealershipSalesAreas) {
            this.DealershipSalesAreas = [];
        }

        this.Country = null;

        this.ImageURL = ImageURL;
    }


    fromJSON(obj: any) {
        this.Id = obj.Id;
        this.Active = obj.Active;
        this.Name = obj.Name;
        this.DealerCode = obj.DealerCode;
        this.DealerManagementSystemCode = obj.DealerManagementSystemCode;
        this.EmailAddress = obj.EmailAddress;
        this.PhoneNumber1 = obj.PhoneNumber1;
        this.PhoneNumber2 = obj.PhoneNumber2;
        this.SpeedDial = obj.SpeedDial;
        this.FaxNumber = obj.FaxNumber;
        this.RegisteredName = obj.RegisteredName;
        this.RegNumber = obj.RegNumber;
        this.VatNumber = obj.VatNumber;
        this.IsAutomarkDealer = obj.IsAutomarkDealer;
        this.IsRetailDealer = obj.IsRetailDealer;
        this.IsVirtualDealer = obj.IsVirtualDealer;
        this.IsServiceDealer = obj.IsServiceDealer;
        this.StreetAddress = obj.StreetAddress;
        this.StreetSuburb = obj.StreetSuburb;
        this.StreetCode = obj.StreetCode;
        this.Postal = obj.Postal;
        this.PostalCity = obj.PostalCity;
        this.PostalCode = obj.PostalCode;
        this.AccountGroup = obj.AccountGroup;
        this.Latitude = obj.Latitude;
        this.Longitude = obj.Longitude;
        this.DealerManagementSystemId = obj.DealerManagementSystemId;
        this.CountryId = obj.CountryId;
        this.DealershipCategoryId = obj.DealershipCategoryId;
        this.ParentDealerId = obj.ParentDealerId;
        this.RegionId = obj.RegionId;
        this.DPName = '';
        this.DPEmail = '';
        this.DPPhoneNumber = '';
        this.SalesManagerName = '';
        this.SalesManagerEmail = '';
        this.SalesManagerPhoneNumber = '';
        this.ServiceManagerName = '';
        this.ServiceManagerEmail = '';
        this.ServiceManagerPhoneNumber = '';

        /* If there is a defined Staff object */
        if (typeof obj.Staff !== 'undefined' && obj.Staff !== null) {
            for (let x = 0; x < obj.Staff.length; x++) {
                /* If there is a defined StaffJobTitles object */
                if (typeof obj.Staff[x].StafFJobTitles !== 'undefined' && obj.Staff[x].StafFJobTitles !== null) {

                    for (let y = 0; y < obj.Staff[x].StaffJobTitles.length; y++) {
                        if (obj.Staff[x].StaffJobTitles[y].JobTitleCode === '05') {
                            this.DPName = obj.Staff[x].FirstName + ' ' + obj.Staff[x].Surname;    //Work with list
                            this.DPEmail = obj.Staff[x].Email;
                            this.DPPhoneNumber = obj.Staff[x].PhoneNumber;
                        }
                        else if (obj.Staff[x].StaffJobTitles[y].JobTitleCode === '07') {
                            this.SalesManagerName = obj.Staff[x].FirstName + ' ' + obj.Staff[x].Surname;    //Work with list
                            this.SalesManagerEmail = obj.Staff[x].Email;
                            this.SalesManagerPhoneNumber = obj.Staff[x].PhoneNumber;
                        }
                        else if (obj.Staff[x].StaffJobTitles[y].JobTitleCode === '54') {
                            this.ServiceManagerName = obj.Staff[x].FirstName + ' ' + obj.Staff[x].Surname;    //Work with list
                            this.ServiceManagerEmail = obj.Staff[x].Email;
                            this.ServiceManagerPhoneNumber = obj.Staff[x].PhoneNumber;
                        }
                    }
                }
            }
        }

        this.DealershipComponents = obj.DealershipComponents;
        if (!this.DealershipComponents) {
            this.DealershipComponents = [];
        }
        this.DealershipSettings = obj.DealershipSettings;
        if (!this.DealershipSettings) {
            this.DealershipSettings = [];
        }

        this.DealershipModules = obj.DealershipModules;
        if (!this.DealershipModules) {
            this.DealershipModules = [];
        }
        this.DealershipList = obj.Staff;
        if (!this.DealershipList) {
            this.DealershipList = [];
        }

        this.DealershipSalesAreas = obj.DealershipSalesAreas;
        if (!this.DealershipSalesAreas) {
            this.DealershipSalesAreas = [];
        }

        if (obj.Country) {
            const c = new Country();
            c.fromJSON(obj.Country);
            this.Country = c;
        }

        this.ImageURL = obj.ImageURL;
    }

    toJSON() {
        return {
            'Id': this.Id,
            'Name': this.Name,
            'DealerCode': this.DealerCode,
            'DealerManagementSystemCode': this.DealerManagementSystemCode,
            'EmailAddress': this.EmailAddress,
            'PhoneNumber1': this.PhoneNumber1,
            'PhoneNumber2': this.PhoneNumber2,
            'SpeedDial': this.SpeedDial,
            'FaxNumber': this.FaxNumber,
            'RegisteredName': this.RegisteredName,
            'RegNumber': this.RegNumber,
            'VatNumber': this.VatNumber,
            'IsAutomarkDealer': this.IsAutomarkDealer,
            'IsRetailDealer': this.IsRetailDealer,
            'IsVirtualDealer': this.IsVirtualDealer,
            'IsServiceDealer': this.IsServiceDealer,
            'StreetAddress': this.StreetAddress,
            'StreetSuburb': this.StreetSuburb,
            'StreetCode': this.StreetCode,
            'Postal': this.Postal,
            'PostalCity': this.PostalCity,
            'PostalCode': this.PostalCode,
            'AccountGroup': this.AccountGroup,
            'Latitude': this.Latitude,
            'Longitude': this.Longitude,
            'DealerManagementSystemId': this.DealerManagementSystemId,
            'CountryId': this.CountryId,
            'DealershipCategoryId': this.DealershipCategoryId,
            'ParentDealerId': this.ParentDealerId,
            'RegionId': this.RegionId,
            'DPName': this.DPName,
            'DPEmail': this.DPEmail,
            'DPPhoneNumber': this.DPPhoneNumber,
            'SalesManagerName': this.SalesManagerName,
            'SalesManagerEmail': this.SalesManagerEmail,
            'SalesManagerPhoneNumber': this.SalesManagerPhoneNumber,
            'ServiceManagerName': this.ServiceManagerName,
            'ServiceManagerEmail': this.ServiceManagerEmail,
            'ServiceManagerPhoneNumber': this.ServiceManagerPhoneNumber,
            'DateCreated': this.DateCreated,
            'DateModified': this.DateModified,
            'Deleted': this.Deleted,
            'Active': this.Active,
            'DealershipDepartment': this.DealershipDepartment,
            'DealershipComponents': this.DealershipComponents,
            'DealershipModules': this.DealershipModules,
            'DealershipList': this.DealershipList
        }
    }

    get DealershipImageURL() {
        return environment.api_url + '/' + this.ImageURL;
    }
}
