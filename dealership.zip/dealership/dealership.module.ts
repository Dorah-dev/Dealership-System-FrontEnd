/**
 * Angular Modules
 */
import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
/**
 * Dealership Module Components
 */
import {DealershipListComponent} from './dealership/dealership-list/dealership-list.component';
import {DealershipFormComponent} from './dealership/dealership-form/dealership-form.component';
/**
 * Custom Modules
 */
import {SharedModule} from '../shared/shared.module';
/**
 * Services
 */
import {DealershipService} from './dealership/dealership.service';
import {DealershipSingleViewComponent} from './dealership-single-view/dealership-single-view/dealership-single-view.component';
import {DealershipTimelineComponent} from './dealership-single-view/dealership-timeline/dealership-timeline.component';
import {DealershipDetailsComponent} from './dealership-single-view/dealership-details/dealership-details.component';
import {DealershipOperatingHoursComponent} from './dealership-single-view/dealership-operating-hours/dealership-operating-hours.component';
import {DealershipSettingsComponent} from './dealership-single-view/dealership-settings/dealership-settings.component';
import {DealershipCalendarComponent} from './dealership-single-view/dealership-calendar/dealership-calendar.component';
import {RouterModule} from '@angular/router';


@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        RouterModule,
    ],
    providers: [DealershipService],
    exports: [DealershipListComponent, DealershipFormComponent],
    declarations: [DealershipListComponent, DealershipFormComponent, DealershipSingleViewComponent,
        DealershipTimelineComponent, DealershipDetailsComponent, DealershipOperatingHoursComponent,
        DealershipSettingsComponent, DealershipCalendarComponent]

})
export class DealershipModule {
}
