/*
 * Angular Modules
 */
import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';

import {DealershipSingleViewComponent} from './dealership-single-view/dealership-single-view/dealership-single-view.component';
import {ConfirmDeactivateGuard} from '../shared/guards/confirm-deactivate.guard';
import {AuthGuardService} from '../auth/services/auth-guard.service';
import {DealershipDetailsComponent} from './dealership-single-view/dealership-details/dealership-details.component';
import {DealershipOperatingHoursComponent} from './dealership-single-view/dealership-operating-hours/dealership-operating-hours.component';
import {DealershipSettingsComponent} from './dealership-single-view/dealership-settings/dealership-settings.component';
import {DealershipCalendarComponent} from './dealership-single-view/dealership-calendar/dealership-calendar.component';


/*
 * Initialize the route.
 * DEALERSHIP.SINGLE_VIEW.TAB.DEALERSHIP_DETAILS
 DEALERSHIP.SINGLE_VIEW.TAB.OPERATING_HOURS
 DEALERSHIP.SINGLE_VIEW.TAB.SETTINGS
 DEALERSHIP.SINGLE_VIEW.TAB.CALENDER
 */
const routes: Routes = [
    {
        path: 'dealer/singleview/:id',
        component: DealershipSingleViewComponent,
        data: {
            title: 'DEALERSHIP.SINGLE_VIEW.TITLE',
            notes: {type: 'dealership'},
            menu: {
                'items': [
                    {
                        title: 'DEALERSHIP.SINGLE_VIEW.TAB.DEALERSHIP_DETAILS',
                        url: 'details',
                        navigate: '../details',
                        icon: 'tft-icon-customer',
                        showMain: true,
                        showSub: true
                    },
                    {
                        title: 'DEALERSHIP.SINGLE_VIEW.TAB.OPERATING_HOURS',
                        url: 'operating-hours',
                        navigate: '../operating-hours',
                        icon: 'tft-icon-customer',
                        showMain: true,
                        showSub: true
                    },
                    {
                        title: 'DEALERSHIP.SINGLE_VIEW.TAB.SETTINGS',
                        url: 'settings',
                        navigate: '../settings',
                        icon: 'tft-icon-customer',
                        showMain: true,
                        showSub: true
                    },
                    {
                        title: 'DEALERSHIP.SINGLE_VIEW.TAB.CALENDER',
                        url: 'calendar',
                        navigate: '../calendar',
                        icon: 'tft-icon-customer',
                        showMain: true,
                        showSub: true
                    },
                ],
                'activity': true
            }
        },
        children: [
            {
                path: 'details',
                component: DealershipDetailsComponent,
                canDeactivate: [ConfirmDeactivateGuard],
                data: {
                    // permissions: {
                    //     only: [''],
                    //     redirectTo: '403'
                    // }
                }, canActivate: [AuthGuardService]
            },
            {
                path: 'operating-hours',
                component: DealershipOperatingHoursComponent
            },
            {
                path: 'settings',
                component: DealershipSettingsComponent
            },
            {
                path: 'calendar',
                component: DealershipCalendarComponent
            }]
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
})
export class DealershipRoutingModule {
}

export const dealershipComponents = [];
