import {Component, EventEmitter, OnDestroy, OnInit, Output} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Subscription} from 'rxjs/Subscription';
import {ActivatedRoute, Router} from '@angular/router';

import {Dealership} from '../../model/dealership';
import {DealershipService} from '../dealership.service';


@Component({
    selector: 'app-dealership-list',
    templateUrl: './dealership-list.component.html',
    styleUrls: ['./dealership-list.component.scss']
})
export class DealershipListComponent implements OnInit, OnDestroy {


    @Output() functionExecuted: EventEmitter<any> = new EventEmitter();

    dealershipList: Array<Dealership>;
    /**
     * Pagination
     */
    currentPage: number;
    totalPages: number;
    totalElements: number;
    pageSize: number;
    sort: any;
    /**
     * Search bar & filters
     */
    search: any = "";
    filter: any = {'Deleted': 0, 'Active': true};
    /**
     * Dealership change related variables
     */
    dealershipListChange: Observable<any>;
    dealershipListChangeSub: Subscription;
    statusChange: Observable<string>;
    statusChangeSub: Subscription;
    functions: Array<any>;
    loading: boolean;

    /**
     * With parameters
     */
    withParams: Array<string>;

    constructor(private dealershipService: DealershipService, private router: Router, private route: ActivatedRoute) {
        this.dealershipList = [];
        this.dealershipListChange = this.dealershipService.subscribeToList();

        this.currentPage = 1;
        this.pageSize = 10;
        this.sort = null;

        this.totalPages = 0;
        this.totalElements = 0;

        this.functions = [{
            'function': 'selectDealership',
            'label': 'Edit',
            'class': 'fa-pencil'
        },
            {
                'function': 'delete',
                'label': 'Delete',
                'class': 'fa-trash'
            }];
        this.statusChange = this.dealershipService.subscribeToStatus();
        this.statusChange.subscribe(status => {
            if (status === 'loading') {
                this.loading = true;
            }
            else {
                this.loading = false;
            }
        });
        this.withParams = ["StaffDealershipDepartments", "DealershipDepartments", "Staff", "Departments"];
        this.filter = {
            'IsRetailDealer': 1,
            //  'jobtitlecodes': '05,07,54'
        };
    }


    ngOnInit(): void {
        this.dealershipListChangeSub = this.dealershipListChange.subscribe(list => {
            this.dealershipList = list.dealerships;
            this.totalPages = list.pages;
            this.totalElements = list.elements;
        });
        this.dealershipService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);

    }

    ngOnDestroy() {
        this.dealershipListChangeSub.unsubscribe();
    }

    /**
     * This method is used to select a Dealership.
     *
     * @param Dealership   The Dealership that is selected
     */
    selectDealership(dealership: Dealership): void {
        this.router.navigate(['dealer/singleview/' + dealership.Id]);
    }

    /**
     * This method is used to display a new page.
     *
     * @param page  The number of the page that is selected
     */
    changePage(page: number) {
        this.currentPage = page;
        this.dealershipService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter);
    }

    /**
     * This method is used to change the size of a page (amount of items displayed per page).
     *
     * @param size   The amount of items that need to be displayed per page
     */
    changePageSize(size: number) {
        this.pageSize = size;
        this.currentPage = 1;
        this.dealershipService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter);
    }

    /**
     * This function allows for the child list component to execute functions in the parent class.
     *
     * @param func   The function that should be executed
     */
    executeFunction(func: any): void {
        this[func['function']](func['obj']);
        this.functionExecuted.emit(func['function']);
    }

    /**
     * This method is used to delete a Dealership.
     *
     * @param Dealership  The Dealership that should be deleted
     */

    /*************************************************************/
    /**
     * This method is used to sort Dealership content per column.
     *
     * @param sort  The data that should be sorted
     */
    doSort(sort: any): void {
        this.sort = sort;
        this.currentPage = 1;
        this.dealershipService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter);
    }

    /**
     * This method is used to search Dealership data.
     *
     * @param search  The phrase(s) for which content should be searched
     */
    doSearch(search: any): void {
        this.search = search;
        this.currentPage = 1;
        this.dealershipService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
    }

    /**
     * This method is used to filter Dealership data per column.
     *
     * @param filtere  The phrase(s) for which content should be filtered
     */
    doFilter(filter: any): void {
        this.filter = filter;
        this.filter.IsRetailDealer = 1;
        this.filter.jobtitlecodes = '05,07,54';
        this.currentPage = 1;
        this.dealershipService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
    }

}
