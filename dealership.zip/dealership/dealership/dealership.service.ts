/**
 * Communication of dEA & DealershipForm with API endpoints -
 * contain custom methods: assign, listPage, fetch, create, update, toggle,
 * delete, subscribeToStatus, subscribeToList, subscribeToForm.
 *
 * @summary   Service to communicate between DealershipListComponent & DealershipFormComponent.
 *
 * @class DealershipService
 */
import {Injectable} from '@angular/core';
import {HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import {Subject} from 'rxjs/Subject';
import {TranslateService} from '@ngx-translate/core';


import {ApiService} from '../../core/api/api.service';
import {AlertService} from '../../shared/alert/alert.service';

import {Dealership} from '../model/dealership';

@Injectable()
export class DealershipService {


    dealershipList: Array<Dealership>;
    dealershipListSubscription: Subject<any>;
    dealershipFormSubscription: Subject<Dealership>;
    status: Subject<string>;

    pageSize;
    currentPage;

    constructor(private api: ApiService, private alert: AlertService, private translate: TranslateService) {
        this.dealershipList = [];
        this.dealershipListSubscription = new Subject();
        this.dealershipFormSubscription = new Subject();
        this.status = new Subject();
        this.status.next('notLoaded');

        this.pageSize = 10;
        this.currentPage = 1;
    }

    /**
     * This method is used to assign data to the Dealership array.
     *
     * @param data This is the data that is assigned
     * @param headers This is the header of the page
     */
    assign(data: Array<Dealership>, headers: HttpHeaders): void {
        const dealerships = [];
        data.forEach((value: any, key: any) => {
            const dealership = new Dealership();
            dealership.fromJSON(value);
            dealerships.push(dealership);
        });
        const dealership_data = {
            dealerships: dealerships,
            pages: headers.get('X-Pages'),
            elements: headers.get('X-Count')
        };
        this.dealershipListSubscription.next(dealership_data);
    }


    /*
     * This method is used to list requested data.
     *
     * @param page      The page to retrieve of the list set
     * @param pageSize  The page size of the page to retrieve
     * @param sort      A sorting object to pass
     * @param search    Remaining search parameters
     * @param filter    Filter parameters
     */
    listPage(page?: number,
             pageSize: number = 1,
             sort: any = null,
             search: string = null,
             filter: any = {},
             withParams: Array<string> = null): void {
        this.status.next('loading');

        // If there is no supplied filter for delete,
        // add a Deleted=false filter to only list available items.
        if (Object.keys(filter).indexOf('Deleted') === -1) {
            filter['Deleted'] = 'false';
        }

        this.api.list('Dealerships', page, pageSize, sort, true, search, filter, withParams)
            .subscribe(
                data => {
                    this.status.next('ready');
                    this.assign(data.body, data.headers);
                },
                error => {
                    this.status.next('error');
                }
            );
    }

    /**
     * This method is used to fetch requested data.
     *
     * @param id This is the id of the dealership that is fetched
     */

    fetch(id: number,
          filter: any = {},
          withParams: Array<string> = null): void {
        this.status.next('loading');
        if (!withParams) {
            withParams = ['dealershipcomponents', 'components', 'dealershipmodules', 'modules', 'dealershipdepartments',
                'departments', 'staffdealershipdepartments', 'staff'];
        }
        this.api.fetch('Dealerships', id, filter, withParams).subscribe(
            data => {
                this.status.next('ready');
                this.dealershipFormSubscription.next(data.body);
            },
            error => {
                this.status.next('error');
            }
        );
    }

    /**
     * This method is used to update a Dealership by putting (update) data.
     *
     * @param Dealership TThis is the Dealership that uses PUT method
     */

    update(dealership: Dealership): void {
        this.status.next('loading');
        this.api.update('Dealerships/' + dealership.Id, dealership).subscribe(
            data => {

                this.translate.get(
                    'DEALERSHIP.ALERT.SUCCESS_UPDATE',
                    {
                        'dealership': dealership.Name
                    })
                    .subscribe((res: string) => {
                        this.alert.success(res);
                    });

                this.status.next('ready');
            },
            error => {
                this.alert.error(error);
                this.status.next('error');
            }
        );
    }


    bulkUpdate(dealerships: Dealership[]): void {
        this.status.next('loading');
        this.api.update('Dealerships/', dealerships).subscribe(
            data => {
                this.status.next('ready');
                this.listPage(1, this.pageSize);
            },
            error => {
                this.status.next('error');
            }
        );
    }

    /**
     * This method is used to subscribe to the status.
     */
    subscribeToStatus(): Observable<string> {
        return this.status.asObservable();
    }

    /**
     * This method is used to subscribe to the list component.
     */
    subscribeToList(): Observable<any> {
        return this.dealershipListSubscription.asObservable();
    }

    /**
     * This method is used to subscribe to the form component.
     */

    subscribeToForm(): Observable<Dealership> {
        return this.dealershipFormSubscription.asObservable();
    }


}
