import {Component, EventEmitter, Input, OnInit, OnDestroy, Output, SimpleChange} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {Location} from '@angular/common';
import {Observable} from 'rxjs/Observable';
import {Subscription} from "rxjs/Subscription";

import {Dealership} from '../../model/dealership';
import {DealershipService} from '../dealership.service';


@Component({
  selector: 'app-dealership-form',
  templateUrl: './dealership-form.component.html',
  styleUrls: ['./dealership-form.component.scss']
})
export class DealershipFormComponent implements OnInit, OnDestroy {

  @Input() dealership: Dealership;
  @Output() formSubmitted: EventEmitter<any> = new EventEmitter();

  loading: boolean;
  statusChange: Observable<string>;
  statusChangeSub: Subscription;
  formChange: Observable<Dealership>;
  formChangeSub: Subscription;
  loadDealershipId: number;
  withParams: Array<string>;
  filter:any;

   constructor(private dealershipService: DealershipService, private route: ActivatedRoute, private router: Router, private location: Location) {
    this.dealership = new Dealership();
    this.statusChange = this.dealershipService.subscribeToStatus();
    this.formChange = this.dealershipService.subscribeToForm();
    this.withParams =  ["dealershipcomponents","dealershipmodules","dealershipdepartments","staffdealershipdepartments","staff","departments","jobtitles"];
    this.filter =  {
         "jobtitlecodes":"05,07,54",
         "IsRetailDealer":"1",
         "Deleted":"false"
    }
  }

    ngOnInit(): void {
    this.statusChangeSub = this.statusChange.subscribe(status => {
      if (status === 'loading') {
        this.loading = true;
      }
      else {
        this.loading = false;
      }
    });
    this.formChangeSub = this.formChange.subscribe(dealership => {
      let newDealership = new Dealership();
      newDealership.fromJSON(dealership);
      this.dealership = newDealership;
    });
    this.route.params.subscribe(params => {
      this.loadDealershipId = +params['id'];
      if (this.dealership.Id === 0) {
        if (this.loadDealershipId > 0) {
          this.dealershipService.fetch(this.loadDealershipId,this.filter,this.withParams);
        }
      }
    });
  }

  ngOnDestroy()
  {
      this.statusChangeSub.unsubscribe();
      this.formChangeSub.unsubscribe();
  }

   /**
   * This method is used to submit data to API.
   *
   * @param dealership The dealership that needs to be added / modified
   */
  submitDealership(dealership: Dealership): void {
    this.dealership = dealership;
    if (this.dealership.Id > 0) {
      this.dealershipService.update(this.dealership);
    }
    this.formSubmitted.emit();
  }

  goBack():void
  {
    this.location.back();
  }


}
