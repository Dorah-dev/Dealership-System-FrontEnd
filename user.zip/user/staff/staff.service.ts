import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Subject} from 'rxjs/Subject';
import {TranslateService} from '@ngx-translate/core';


import {Staff} from '../model/staff';


import {ApiService} from '../../core/api/api.service';
import {AlertService} from '../../shared/alert/alert.service';
import {ModelService} from '../../shared/interfaces/model-service';
import {HttpHeaders} from '@angular/common/http';

@Injectable()
export class StaffService implements ModelService {

    staffList: Array<Staff>;
    staffListSubscription: Subject<any>;
    staffFormSubscription: Subject<Staff>;
    status: Subject<string>;

    pageSize: number;
    currentPage: number;

    constructor(private api: ApiService, private alert: AlertService, private translate: TranslateService) {
        this.staffList = [];
        this.staffListSubscription = new Subject();
        this.staffFormSubscription = new Subject();
        this.status = new Subject();
        this.status.next('notLoaded');

        this.pageSize = 10;
        this.currentPage = 1;
    }

    assign(data: Array<Staff>, headers: HttpHeaders): void {
        const staffs = [];
        data.forEach((value: any, key: any) => {
            const staff = new Staff();
            staff.fromJSON(value);
            staffs.push(staff);
        });

        const staff_data = {
            staffs: staffs,
            pages: headers.get('X-Pages'),
            elements: headers.get('X-Count')
        };
        this.staffListSubscription.next(staff_data);
    }

    listPage(page?: number,
             pageSize: number = 1,
             sort: any = null, search: string = null,
             filter: any = {},
             withParams: Array<string> = null): void {
        this.status.next('loading');

        // If there is no supplied filter for delete,
        // add a Deleted=false filter to only list available items.
        if (Object.keys(filter).indexOf('Deleted') === -1) {
            filter['Deleted'] = 'false';
        }

        this.api.list('Staff', page, pageSize, sort, true, search, filter, withParams)
            .subscribe(
                data => {
                    this.status.next('ready');
                    this.assign(data.body, data.headers);
                },
                error => {
                    this.status.next('error');
                }
            );
    }

    fetch(id: number,
          filter: any = {},
          withParams: Array<string> = null): void {
        this.status.next('loading');
        if (!withParams) {
            withParams = ['staffdealershipdepartments', 'dealershipdepartments', 'departments', 'dealerships',
                'staffjobtitles', 'jobtitles', 'jobtitleroles', 'users', 'userfeatures', 'userroles', 'roles', 'roleFeatures'];
        }
        this.api.fetch('Staff', id, filter, withParams).subscribe(
            data => {
                this.status.next('ready');
                this.staffFormSubscription.next(data.body);
            },
            error => {
                this.status.next('error');
            }
        );
    }


    create(staff: Staff): void {
        this.status.next('loading');
        delete staff.Id;
        this.api.create('Staff', staff).subscribe(
            data => {
                this.translate.get('STAFF.ALERT.SUCCESS_CREATE', {'staff': staff.FirstName + ' ' + staff.Surname})
                    .subscribe((res: string) => {
                        this.alert.success(res);
                    });
                this.listPage(this.currentPage, this.pageSize, null, null);
            },
            error => {
                this.alert.error(error);
                this.status.next('error');
            }
        );
    }

    update(staff: Staff): void {
        this.status.next('loading');
        this.api.update('Staff/' + staff.Id, staff).subscribe(
            data => {
                this.translate.get('STAFF.ALERT.SUCCESS_UPDATE', {'staff': staff.FirstName + ' ' + staff.Surname})
                    .subscribe((res: string) => {
                        this.alert.success(res);
                    });
                this.status.next('ready');
            },
            error => {
                this.alert.error(error);
                this.status.next('error');
            }
        );
    }

    toggle(staff: Staff): void {
        staff.Active = !staff.Active;
        this.update(staff);
    }

    bulkUpdate(staff: Staff[]): void {
        this.status.next('loading');
        this.api.update('Staff/', staff).subscribe(
            data => {
                this.translate.get('STAFF.ALERT.SUCCESS_DELETE_MULTI').subscribe((res: string) => {
                    this.alert.success(res);
                });
                this.status.next('ready');
                this.listPage(1, this.pageSize);
            },
            error => {
                this.status.next('error');
            }
        );
    }

    delete(staff: Staff[]): void {
        for (let i = 0; i < staff.length; i++) {
            delete staff[i].formProperties;
            staff[i].Deleted = true;
        }
        this.bulkUpdate(staff);
    }

    /**
     * This method is used to subscribe to the status.
     */
    subscribeToStatus(): Observable<string> {
        return this.status.asObservable();
    }

    /**
     * This method is used to subscribe to the list component.
     */
    subscribeToList(): Observable<any> {
        return this.staffListSubscription.asObservable();
    }

    /**
     * This method is used to subscribe to the form component.
     */
    subscribeToForm(): Observable<Staff> {
        return this.staffFormSubscription.asObservable();
    }

}
