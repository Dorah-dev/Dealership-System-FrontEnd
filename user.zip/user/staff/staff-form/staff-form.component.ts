import {Component, EventEmitter, Input, OnInit, OnDestroy, Output, SimpleChange} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {Location} from '@angular/common';
import {Observable} from 'rxjs/Observable';
import {Subscription} from "rxjs/Subscription";

import {Staff} from '../../model/staff';
import {StaffService} from '../staff.service';



@Component({
  selector: 'app-staff-form',
  templateUrl: './staff-form.component.html',
  styleUrls: ['./staff-form.component.scss']
})
export class StaffFormComponent implements OnInit, OnDestroy {

  @Input() staff: Staff;
  @Output() formSubmitted: EventEmitter<any> = new EventEmitter();

  loading: boolean;
  loadStaffId: number;
  statusChange: Observable<string>;
  statusChangeSub: Subscription;
  formChange: Observable<Staff>;
  formChangeSub: Subscription;

  filter:any;
  withParams: Array<string> = ['staffdealershipdepartments','dealershipdepartments','departments','dealerships',
                              'staffjobtitles','jobtitles','jobtitleroles','user','userfeatures','userroles', 'roles', 'rolefeatures'];


  constructor(private staffService: StaffService, private route: ActivatedRoute, private router: Router, private location: Location) {
    this.staff = new Staff();
    this.statusChange = this.staffService.subscribeToStatus();
    this.formChange = this.staffService.subscribeToForm();
   }

    ngOnInit(): void {
    this.statusChangeSub = this.statusChange.subscribe(status => {
      if (status === 'loading') {
        this.loading = true;
      }
      else {
        this.loading = false;
      }
    });
    this.formChangeSub = this.formChange.subscribe(staff => {
      let newStaff = new Staff();
      newStaff.fromJSON(staff);
      this.staff = newStaff;
    });
    this.route.params.subscribe(params => {
      this.loadStaffId = +params['id'];
      if (this.staff.Id === 0) {
        if (this.loadStaffId > 0) {
          this.staffService.fetch(this.loadStaffId,this.filter,this.withParams);
        }
      }
    });
  }

  ngOnDestroy()
  {
      this.statusChangeSub.unsubscribe();
      this.formChangeSub.unsubscribe();
  }

   /**
   * This method is used to submit data to API.
   *
   * @param staff The staff that needs to be added / modified
   */
  submitStaff(staff: Staff): void {
    this.staff = staff;
    if (this.staff.Id > 0) {
      this.staffService.update(this.staff);
    }
    this.formSubmitted.emit();
  }

  goBack():void
  {
    this.location.back();
  }

}
