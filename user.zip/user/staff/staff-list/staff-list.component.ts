import {Component, EventEmitter, OnInit, OnDestroy, Output, Input} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Subscription} from "rxjs/Subscription";
import {ActivatedRoute, Router} from "@angular/router";

import {Staff} from '../../model/staff';
import {StaffService} from '../staff.service';


@Component({
  selector: 'app-staff-list',
  templateUrl: './staff-list.component.html',
  styleUrls: ['./staff-list.component.scss']
})
export class StaffListComponent implements OnInit, OnDestroy {

  @Output() functionExecuted: EventEmitter<any> = new EventEmitter();
  @Input() staff: Staff;

  staffList: Array<Staff>;

  /**
   * Pagination
   */
  currentPage: number;
  totalPages: number;
  totalElements: number;
  pageSize: number;
  sort: any;

  /**
   * Search bar & filters
   */
  search: any;
  filter: any = { 'Deleted': 0, 'Active': true};

  /**
   * Role change related variables
   */
  staffListChange: Observable<any>;
  staffListChangeSub: Subscription;
  statusChange: Observable<string>;
  statusChangeSub: Subscription;
  functions: Array<any>;
  loading: boolean;

 /**
   * With parameters
   */
  withParams: Array<string> = ["StaffDealershipDepartments", "DealershipDepartments", "Dealerships","Departments"];

  constructor(private staffService: StaffService, private router:Router, private route: ActivatedRoute) {

    this.staffList = [];
    this.staffListChange = this.staffService.subscribeToList();

    this.currentPage = 1;
    this.pageSize = 10;
    this.sort = null;

    this.totalPages = 0;
    this.totalElements = 0;

    this.functions = [{
        'function': 'selectStaff',
        'label': 'Edit',
        'class': 'fa-pencil'
      },
      {
        'function': 'delete',
        'label': 'Delete',
        'class': 'fa-trash'
      }];
    this.statusChange = this.staffService.subscribeToStatus();
    this.statusChange.subscribe(status => {
      if (status === 'loading') {
        this.loading = true;
      }
      else {
        this.loading = false;
      }
    });
   }

  ngOnInit(): void {
    this.staffListChangeSub = this.staffListChange.subscribe(list => {
      this.staffList = list.staffs;
      this.totalPages = list.pages;
      this.totalElements = list.elements;
    });
    this.staffService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  ngOnDestroy()
  {
      this.staffListChangeSub.unsubscribe();
  }

  selectStaff(staff: Staff): void {
     this.router.navigate(['./edit/'+staff.Id], {relativeTo: this.route});
  }

   changePage(page: number) {
    this.currentPage = page;
    this.staffService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  changePageSize(size: number) {
    this.pageSize = size;
    this.currentPage = 1;
    this.staffService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  executeFunction(func: any): void {
    this[func['function']](func['obj']);
    this.functionExecuted.emit(func['function']);
  }

  toggle(staff: Staff): void {
    this.staffService.toggle(staff);
  }

  delete(staffs: Staff[]): void {
    this.staffService.delete(staffs);
  }

  doSort(sort: any): void {
    this.sort = sort;
    this.currentPage = 1;
    this.staffService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  doSearch(search:any):void {
    this.search = search;
    this.currentPage = 1;
    this.staffService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  doFilter(filter:any):void {
    this.filter = filter;
    this.currentPage = 1;
    this.staffService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

}
