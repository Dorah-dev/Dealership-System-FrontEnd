/**
* Angular Modules
*/
import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

/**
* Custom Modules
*/
import {SharedModule} from '../shared/shared.module';
import {NgbModule} from "@ng-bootstrap/ng-bootstrap";

/**
* Services
*/
import {RoleService} from './role/role.service';
import {UserService} from './user/user.service';
import {StaffService} from './staff/staff.service';

/**
* User Module Components
*/
import {RoleFormComponent} from './role/role-form/role-form.component';
import {RoleListComponent} from './role/role-list/role-list.component';
import {UserFormComponent } from './user/user-form/user-form.component';
import {UserListComponent } from './user/user-list/user-list.component';
import {StaffListComponent } from './staff/staff-list/staff-list.component';
import {StaffFormComponent } from './staff/staff-form/staff-form.component';
import {CityListComponent} from "./city/city-list/city-list.component";
import {CityService} from "./city/city.service";

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    NgbModule.forRoot()
  ],
  entryComponents:[CityListComponent],
  exports: [RoleFormComponent, RoleListComponent, StaffListComponent, UserFormComponent, UserListComponent],
  providers: [RoleService, StaffService, UserService, CityService],
  declarations: [RoleFormComponent, RoleListComponent, StaffListComponent, UserFormComponent, UserListComponent, StaffFormComponent, CityListComponent]
})
export class UserModule {
}
