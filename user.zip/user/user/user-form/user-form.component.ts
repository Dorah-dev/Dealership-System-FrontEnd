/**
 * @summary  Generates and displays a dynamic form based on the user passed to it.
 *
 * @class UserFormComponent
 *
 * @param user   The user that need to be rendered
 * @returns formSubmitted  When a form is submitted an event will be fired that contains the content.
 */

import {Component, EventEmitter, Input, OnInit, OnDestroy, Output, SimpleChange} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {Location} from '@angular/common';
import {Observable} from 'rxjs/Observable';
import {Subscription} from "rxjs/Subscription";

import {User} from '../../model/user';
import {Staff} from '../../model/staff';
import {Customer} from '../../../customer/model/customer';
import {UserService} from '../user.service';


@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.scss']
})
export class UserFormComponent implements OnInit, OnDestroy {

  @Input() user: User;
  @Output() formSubmitted: EventEmitter<any> = new EventEmitter();

  loading: boolean;
  statusChange: Observable<string>;
  statusChangeSub: Subscription;
  formChange: Observable<User>;
  formChangeSub: Subscription;
  loadUserId: number;
  customerDisplayName:string;
  staffDisplayName:string;
  displayProperties:Array<string>;

  constructor(private userService: UserService, private route: ActivatedRoute, private router: Router, private location: Location) {
    this.user = new User();
    this.statusChange = this.userService.subscribeToStatus();
    this.formChange = this.userService.subscribeToForm();
    this.displayProperties =  ['FirstName','Surname'];
  }

  public ngOnInit(): void {
    this.statusChangeSub = this.statusChange.subscribe(status => {
      if (status === 'loading') {
        this.loading = true;
      }
      else {
        this.loading = false;
      }
    });
    this.formChangeSub = this.formChange.subscribe(user => {
      let newUser = new User();
      newUser.fromJSON(user);
      this.user = newUser;
       if(this.user.staff.Id > 0)
        {
          this.staffDisplayName = "";
          for(var y=0; y<this.displayProperties.length;y++)
          {
            if(this.user.staff[this.displayProperties[y]])
            {
              this.staffDisplayName += this.user.staff[this.displayProperties[y]] + " ";
            }
          }
        }
        //DISPLAY CUSTOMER LIST ON USER FORM
        if(this.user.customer.Id > 0)
        {
          this.customerDisplayName = "";
          for(var y=0; y<this.displayProperties.length;y++)
          {
            if(this.user.customer[this.displayProperties[y]])
            {
               this.customerDisplayName += this.user.customer[this.displayProperties[y]] + " ";
            }
          }
        }
    });
    this.route.params.subscribe(params => {
      this.loadUserId = +params['id'];
      if (this.user.Id === 0) {
        if (this.loadUserId > 0) {
          this.userService.fetch(this.loadUserId);
        }
      }
    });
  }

  ngOnDestroy()
  {
      this.statusChangeSub.unsubscribe();
      this.formChangeSub.unsubscribe();
  }

  /**
   * This method is used to submit data to API.
   *
   * @param user The user that needs to be added / modified
   */
  submitUser(user: User): void {
    this.user = user;
    if (this.user.Id > 0) {
      this.userService.update(this.user);
    }
    else {
      this.userService.create(this.user);
      this.user = new User();
      this.router.navigate(['../'], {relativeTo: this.route});
    }
  }

  /**
   * This method is used to delete a user.
   *
   * @param user The user that needs to be added / modified
   */
  deleteUser(): void {
    this.user.Deleted = true;
    this.userService.delete([this.user]);
    this.router.navigate(['../../'], {relativeTo: this.route});

  }

  selectStaff(user: any): void {

     let staff = new Staff();
     staff.fromJSON(user);
     this.user.staff = staff;
  }


  selectCustomer(user: any): void {
    let customer = new Customer();
    customer.fromJSON(user);
     this.user.customer = customer;
  }

  goBack():void
  {
    this.location.back();
  }

}
