/**
 * @summary  Generates and displays a dynamic list based on the user passed to it.
 *
 * @class UserListComponent
 *
 * @returns selectedUser      When an item on the list is selected an event will be fired that contains the selected content.
 * @returns functionExecuted  When a function is executed an event will be fired that performs the function.
 */

import {Component, EventEmitter, OnInit, OnDestroy, Output} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Subscription} from "rxjs/Subscription";
import {ActivatedRoute, Router} from "@angular/router";

import {User} from '../../model/user';
import {UserService} from '../user.service';

import {ConfirmComponent} from '../../../shared/alert/confirm/confirm.component';
import {NgbModal, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})
export class UserListComponent implements OnInit, OnDestroy {

  @Output() functionExecuted: EventEmitter<any> = new EventEmitter();

  userList: Array<User>;

  /**
   * Pagination
   */
  currentPage: number;
  totalPages: number;
  totalElements: number;
  pageSize: number;
  sort: any;

  /**
   * Search bar & filters
   */
  search: any;
  filter: any = { 'Deleted': 0 };

  /**
   * User change related variables
   */
  userListChange: Observable<any>;
  userListChangeSub: Subscription;
  statusChange: Observable<string>;
  statusChangeSub: Subscription;
  functions: Array<any>;
  loading: boolean;

  /**
   * With parameters
   */
  withParams: Array<string> = ["Staff", "Customers"];

  constructor(private userService: UserService, private router:Router, private route: ActivatedRoute,
              private modalService: NgbModal) {
    this.userList = [];
    this.userListChange = this.userService.subscribeToList();

    this.currentPage = 1;
    this.pageSize = 10;
    this.sort = null;

    this.totalPages = 0;
    this.totalElements = 0;

    this.functions = [];
    this.statusChange = this.userService.subscribeToStatus();
    this.statusChange.subscribe(status => {
      if (status === 'loading') {
        this.loading = true;
      }
      else {
        this.loading = false;
      }
    });
  }

  public ngOnInit(): void {
    this.userListChangeSub = this.userListChange.subscribe(list => {
      this.userList = list.users;
      this.totalPages = list.pages;
      this.totalElements = list.elements;
    });

    this.userService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  ngOnDestroy()
  {
      this.userListChangeSub.unsubscribe();
  }

  /**
   * This method is used to select a user.
   *
   * @param user   The user that is selected
   */
  selectUser(user: User): void {
      this.router.navigate(['./edit/'+user.Id], {relativeTo: this.route});
  }

  /**
   * This method is used to display a new page.
   *
   * @param page  The number of the page that is selected
   */
  changePage(page: number) {
    this.currentPage = page;
    this.userService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  /**
   * This method is used to change the size of a page (amount of items displayed per page).
   *
   * @param size   The amount of items that need to be displayed per page
   */
  changePageSize(size: number) {
    this.pageSize = size;
    this.currentPage = 1;
    this.userService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  /**
   * This function allows for the child list component to execute functions in the parent class.
   *
   * @param func   The function that should be executed
   */
  executeFunction(func: any): void {
    this[func['function']](func['obj']);
    this.functionExecuted.emit(func['function']);
  }

  /**
   * This method is used to toggle between 'active' & 'inactive'.
   *
   * @param user  The user that should be toggled
   */
  toggle(user: User): void {
    this.userService.toggle(user, this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  /**
   * This method is used to delete a user.
   *
   * @param user  The user that should be deleted
   */
  delete(users: User[]): void {
    this.userService.delete(users, this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  /**
   * This method is used to sort user content per column.
   *
   * @param sort  The data that should be sorted
   */
  doSort(sort: any): void {
    this.sort = sort;
    this.currentPage = 1;
    this.userService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  /**
   * This method is used to search user data.
   *
   * @param search  The phrase(s) for which content should be searched
   */
  doSearch(search:any):void {
    this.search = search;
    this.currentPage = 1;
    this.userService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  /**
   * This method is used to filter user data per column.
   *
   * @param filter  The phrase(s) for which content should be filtered
   */
  doFilter(filter:any):void {
    this.filter = filter;
    this.currentPage = 1;
    this.userService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  doCreate() {
    this.router.navigate(['./create'], {relativeTo: this.route});
  }

  openConfirmModal(users: User[]) {
    const options: NgbModalOptions = {
        size: 'sm'
    };

    const modalRef = this.modalService.open(ConfirmComponent, options);

    modalRef.componentInstance.titleText = 'GENERAL.CONFIRM.TEXT';
    modalRef.componentInstance.mainText = 'GENERAL.CONFIRM.MAIN_TEXT';

    modalRef.result
        .then(close => {
            this.delete(users);
        }, dismissed => {
            // Remain silent if dismissed
        });
}
}
