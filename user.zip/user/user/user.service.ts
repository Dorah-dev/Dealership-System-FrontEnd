/**
 * Communication of UserList & UserForm with API endpoints -
 * contain custom methods: assign, listPage, fetch, create, update, toggle,
 * delete, subscribeToStatus, subscribeToList, subscribeToForm.
 *
 * @summary   Service to communicate between UserListComponent & UserFormComponent.
 *
 * @class UserService
 */

import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Subject} from 'rxjs/Subject';
import {TranslateService} from '@ngx-translate/core';


import {User} from '../model/user';

import {ApiService} from '../../core/api/api.service';
import {AlertService} from '../../shared/alert/alert.service';
import {ModelService} from '../../shared/interfaces/model-service';
import {HttpHeaders} from '@angular/common/http';

@Injectable()
export class UserService implements ModelService {

    userList: Array<User>;
    userListSubscription: Subject<any>;
    userFormSubscription: Subject<User>;
    status: Subject<string>;

    pageSize;
    currentPage;

    constructor(private api: ApiService, private alert: AlertService, private translate: TranslateService) {
        this.userList = [];
        this.userListSubscription = new Subject();
        this.userFormSubscription = new Subject();
        this.status = new Subject();
        this.status.next('notLoaded');

        this.pageSize = 10;
        this.currentPage = 1;

    }

    /**
     * This method is used to assign data to the user array.
     *
     * @param data This is the data that is assigned
     * @param headers This is the header of the page
     */
    assign(data: Array<User>, headers: HttpHeaders): void {
        const users = [];
        data.forEach((value: any, key: any) => {
            const user = new User();
            user.fromJSON(value);
            users.push(user);
        });

        const user_data = {
            users: users,
            pages: headers.get('X-Pages'),
            elements: headers.get('X-Count')
        };
        this.userListSubscription.next(user_data);
    }

    /**
     * This method is used to list requested data.
     *
     * @param page      The page to retrieve of the list set
     * @param pageSize  The page size of the page to retrieve
     * @param sort      A sorting object to pass
     * @param search    Remaining search parameters
     * @param filter    Filter parameters
     */
    listPage(page?: number,
             pageSize: number = 1,
             sort: any = null,
             search: string = null,
             filter: any = {},
             withParams: Array<string> = null): void {
        this.status.next('loading');

        // If there is no supplied filter for delete,
        // add a Deleted=false filter to only list available items.
        if (Object.keys(filter).indexOf('Deleted') === -1) {
            filter['Deleted'] = 'false';
        }

        this.api.list('Users', page, pageSize, sort, true, search, filter, withParams)
            .subscribe(
                data => {
                    this.status.next('ready');
                    this.assign(data.body, data.headers);
                },
                error => {
                    this.status.next('error');
                }
            );
    }

    /**
     * This method is used to fetch requested data.
     *
     * @param id This is the id of the user that is fetched
     */
    fetch(id: number,
          filter: any = {},
          withParams: Array<string> = null): void {
        this.status.next('loading');
        // if(!withParams)
        // {
        //   withParams = ['userfeatures','userroles','roles','rolefeatures'];
        // }
        this.api.fetch('Users', id, filter, withParams).subscribe(
            data => {
                this.status.next('ready');
                this.userFormSubscription.next(data.body);
            },
            error => {
                this.status.next('error');
            }
        );

    }

    /**
     * This method is used to create a user by posting (save) data.
     *
     * @param user This is the user that uses POST method
     */
    create(user: User): void {
        this.status.next('loading');
        delete user.Id;
        this.api.create('Users', user).subscribe(
            data => {
                this.translate.get('USER.ALERT.SUCCESS_CREATE', (user.staff) ? {'user': user.staff.FirstName + ' ' + user.staff.Surname} : {'user': user.customer.FirstName + ' ' + user.customer.Surname}).subscribe((res: string) => {
                    this.alert.success(res);
                });
                this.listPage(this.currentPage, this.pageSize, null, null);
            },
            error => {
                this.alert.error(error);
                this.status.next('error');
            }
        );
    }

    /**
     * This method is used to update a user by putting (update) data.
     *
     * @param user This is the user that uses PUT method
     */
    update(user: User,
           page: number = 1,
           pageSize: number = 10,
           sort: any = null,
           search: string = null,
           filter: any = {},
           withParams: Array<string> = null,
           reloadList = true): void {
        this.status.next('loading');
        this.api.update('Users/' + user.Id, user).subscribe(
            data => {
                this.translate.get('USER.ALERT.SUCCESS_UPDATE', (user.staff) ? {'user': user.staff.FirstName + ' ' + user.staff.Surname} : {'user': user.customer.FirstName + ' ' + user.customer.Surname}).subscribe((res: string) => {
                    this.alert.success(res);
                });

                if (reloadList) {
                    this.listPage(page, pageSize, sort, search, filter, withParams);
                } else {
                    this.status.next('ready');
                }

            },
            error => {
                this.alert.error(error);
                this.status.next('error');
            }
        );
    }

    bulkUpdate(users: User[],
               page: number = 1,
               pageSize: number = 10,
               sort: any = null,
               search: string = null,
               filter: any = {},
               withParams: Array<string> = null,
               reloadList = true): void {
        this.status.next('loading');
        this.api.update('Users/', users).subscribe(
            data => {

                this.translate.get('USER.ALERT.SUCCESS_DELETE_MULTI').subscribe((res: string) => {
                    this.alert.success(res);
                });

                if (reloadList) {
                    this.listPage(page, pageSize, sort, search, filter, withParams);
                } else {
                    this.status.next('ready');
                }

            },
            error => {
                this.status.next('error');
                this.translate.get('USER.ALERT.FAIL_DELETE').subscribe((res: string) => {
                    this.alert.error(res);
                });
            }
        );
    }

    /**
     * This method is used to toggle a user to be active / inactive.
     *
     * @param user This is the user that is toggled
     */
    toggle(user: User,
           page: number = 1,
           pageSize: number = 10,
           sort: any = null,
           search: string = null,
           filter: any = {},
           withParams: Array<string> = null,
           reloadList = false): void {
        user.Active = !user.Active;
        this.update(user,
            page,
            pageSize,
            sort,
            search,
            filter,
            withParams,
            reloadList);
    }

    /**
     * This method is used to delete a user.
     *
     * @param user This is the user that uses the DELETE method
     */
    delete(users: User[],
           page: number = 1,
           pageSize: number = 10,
           sort: any = null,
           search: string = null,
           filter: any = {},
           withParams: Array<string> = null): void {
        for (let i = 0; i < users.length; i++) {
            delete users[i].formProperties;
            users[i].Deleted = true;
        }
        this.bulkUpdate(users, page, pageSize, sort, search, filter, withParams);
    }

    /**
     * This method is used to subscribe to the status.
     */
    subscribeToStatus(): Observable<string> {
        return this.status.asObservable();
    }

    /**
     * This method is used to subscribe to the list component.
     */
    subscribeToList(): Observable<any> {
        return this.userListSubscription.asObservable();
    }

    /**
     * This method is used to subscribe to the form component.
     */
    subscribeToForm(): Observable<User> {
        return this.userFormSubscription.asObservable();
    }

}
