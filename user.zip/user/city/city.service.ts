import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {City} from '../../shared/lookups/model/city';
import {Subject} from 'rxjs/Subject';
import {ApiService} from '../../core/api/api.service';
import {HttpHeaders} from '@angular/common/http';

@Injectable()
export class CityService {

    cityList: Array<City>;
    listSubscription: Subject<any>;
    formSubscription: Subject<City>;
    status: Subject<string>;

    pageSize;
    currentPage;

    constructor(private api: ApiService) {
        this.cityList = [];
        this.listSubscription = new Subject<any>();
        this.formSubscription = new Subject<City>();
        this.status = new Subject<any>();

    }

    assign(data: Array<any>, headers: HttpHeaders): void {
        const cities = [];
        data.forEach((value: any, key: any) => {
            const city = new City();
            city.fromJSON(value);
            cities.push(city);
        });

        const city_data = {
            users: cities,
            pages: headers.get('X-Pages'),
            elements: headers.get('X-Count')
        };
        this.listSubscription.next(city_data);
    }

    listPage(page?: number, pageSize?: number, sort?: any, search?: string, filter?: any, withParams?: Array<string>): void {
        this.status.next('loading');

        // If there is no supplied filter for delete, add a Deleted=false filter to only list available items.
        if (Object.keys(filter).indexOf('Deleted') === -1) {
            filter['Deleted'] = 'false';
        }
        this.api.list('Cities', page, pageSize, sort, true, search, filter, withParams).subscribe(
            data => {
                this.status.next('ready');
                this.assign(data.body, data.headers);
            },
            error => {
                this.status.next('error');
            }
        );
    }

    fetch(id: number, filter: any, withParams: Array<string>): void {

        this.status.next('loading');
        this.api.fetch('Cities', id).subscribe(
            data => {
                this.status.next('ready');
                this.formSubscription.next(data.body);
            },
            error => {
                this.status.next('error');
            }
        );
    }

    subscribeToStatus(): Observable<string> {
        return this.status.asObservable();
    }

    subscribeToList(): Observable<any> {
        return this.listSubscription.asObservable();
    }

    subscribeToForm(): Observable<any> {
        return this.formSubscription.asObservable();
    }


}
