import {Component, EventEmitter, OnInit, OnDestroy, Output} from '@angular/core';
import {Observable} from "rxjs/Observable";
import {Subscription} from "rxjs/Subscription";
import {ActivatedRoute, Router} from "@angular/router";
import {NgbActiveModal} from "@ng-bootstrap/ng-bootstrap";


import {City} from "../../../shared/lookups/model/city";
import {CityService} from "../city.service";

@Component({
  selector: 'app-city-list',
  templateUrl: './city-list.component.html',
  styleUrls: ['./city-list.component.scss']
})
export class CityListComponent implements OnInit, OnDestroy {


  @Output() functionExecuted: EventEmitter<any> = new EventEmitter();

  cityList: Array<City>;

  /**
   * Pagination
   */
  currentPage: number;
  totalPages: number;
  totalElements: number;
  pageSize: number;
  sort: any;

  /**
   * Search bar & filters
   */
  search: any;
  filter: any = { 'Deleted': 0 };

  /**
   * User change related variables
   */
  userListChange: Observable<any>;
  userListChangeSub: Subscription;
  statusChange: Observable<string>;
  statusChangeSub: Subscription;
  functions: Array<any>;
  loading: boolean;

  /**
   * With parameters
   */
  withParams: Array<string> = ["Countries"];

  constructor(private cityService: CityService, public activeModal: NgbActiveModal) {
    this.cityList = [];
    this.userListChange = this.cityService.subscribeToList();

    this.currentPage = 1;
    this.pageSize = 10;
    this.sort = null;

    this.totalPages = 0;
    this.totalElements = 0;

    this.functions = [];
    this.statusChange = this.cityService.subscribeToStatus();
    this.statusChange.subscribe(status => {
      if (status === 'loading') {
        this.loading = true;
      }
      else {
        this.loading = false;
      }
    });
  }

  public ngOnInit(): void {
    this.userListChangeSub = this.userListChange.subscribe(list => {
      this.cityList = list.users;
      this.totalPages = list.pages;
      this.totalElements = list.elements;
    });

    this.cityService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  ngOnDestroy()
  {
      this.userListChangeSub.unsubscribe();
  }

  /**
   * This method is used to select a user.
   *
   * @param user   The user that is selected
   */
  selectCity(city: City): void {
    // this.router.navigate(['./edit/'+city.Id], {relativeTo: this.route});
    this.activeModal.close(city);
  }

  /**
   * This method is used to display a new page.
   *
   * @param page  The number of the page that is selected
   */
  changePage(page: number) {
    this.currentPage = page;
    this.cityService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  /**
   * This method is used to change the size of a page (amount of items displayed per page).
   *
   * @param size   The amount of items that need to be displayed per page
   */
  changePageSize(size: number) {
    this.pageSize = size;
    this.currentPage = 1;
    this.cityService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  /**
   * This function allows for the child list component to execute functions in the parent class.
   *
   * @param func   The function that should be executed
   */
  executeFunction(func: any): void {
    this[func['function']](func['obj']);
    this.functionExecuted.emit(func['function']);
  }

  /**
   * This method is used to toggle between 'active' & 'inactive'.
   *
   * @param city  The user that should be toggled
   */
  toggle(city: City): void {
    // this.cityService.toggle(city);
  }

  /**
   * This method is used to delete a user.
   *
   * @param user  The user that should be deleted
   */
  delete(cities: City[]): void {
    // this.cityService.delete(users, this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  /**
   * This method is used to sort user content per column.
   *
   * @param sort  The data that should be sorted
   */
  doSort(sort: any): void {
    this.sort = sort;
    this.currentPage = 1;
    this.cityService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  /**
   * This method is used to search user data.
   *
   * @param search  The phrase(s) for which content should be searched
   */
  doSearch(search: any): void {
    this.search = search;
    this.currentPage = 1;
    this.cityService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

  /**
   * This method is used to filter user data per column.
   *
   * @param filter  The phrase(s) for which content should be filtered
   */
  doFilter(filter: any): void {
    this.filter = filter;
    this.currentPage = 1;
    this.cityService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter, this.withParams);
  }

}
