/**
 * @summary  Generates and displays a dynamic form based on the role passed to it.
 *
 * @class RoleListComponent
 *
 * @param role   The role that need to be rendered
 * @returns formSubmitted  When a form is submitted an event will be fired that contains the content.
 */

import {Component, EventEmitter, Input, OnInit, OnDestroy, Output} from "@angular/core";
import {ActivatedRoute, Router} from "@angular/router";
import {Location} from '@angular/common';
import {Observable} from "rxjs/Observable";
import {Subscription} from "rxjs/Subscription";

import {Role} from "../../model/role";
import {RoleService} from "../role.service";


@Component({
  selector: 'app-role-form',
  templateUrl: './role-form.component.html',
  styleUrls: ['./role-form.component.scss']
})
export class RoleFormComponent implements OnInit, OnDestroy {

  @Input() role: Role;
  @Output() formSubmitted: EventEmitter<any> = new EventEmitter();

  loading: boolean;
  loadRoleId: number;
  statusChange: Observable<string>;
  statusChangeSub: Subscription;
  formChange: Observable<Role>;
  formChangeSub: Subscription;

  constructor(private roleService: RoleService, private route: ActivatedRoute, private router: Router, private location: Location) {
    this.role = new Role();
    this.statusChange = this.roleService.subscribeToStatus();
    this.formChange = this.roleService.subscribeToForm();
  }

  ngOnInit(): void {
    this.statusChangeSub = this.statusChange.subscribe(status => {
      if (status === 'loading') {
        this.loading = true;
      }
      else {
        this.loading = false;
      }
    });
    this.formChangeSub = this.formChange.subscribe(role => {
      let newRole = new Role();
      newRole.fromJSON(role);
      this.role = newRole;
    });
    this.route.params.subscribe(params => {
      this.loadRoleId = +params['id'];
      if (this.role.Id === 0) {
        if (this.loadRoleId > 0) {
          this.roleService.fetch(this.loadRoleId);
        }
      }
    });
  }

  ngOnDestroy()
  {
      this.statusChangeSub.unsubscribe();
      this.formChangeSub.unsubscribe();
  }

  /**
   * This method is used to submit data to API.
   *
   * @param role The role that needs to be added / modified
   */
  submitRole(role: Role): void {
    this.role = role;
    if (this.role.Id > 0) {
      this.roleService.update(this.role);
    }
    else {
      this.roleService.create(this.role);
      this.role = new Role();
      this.router.navigate(['../'], {relativeTo: this.route});
    }
    this.formSubmitted.emit();

  }

  goBack():void
  {
    this.location.back();
  }

}
