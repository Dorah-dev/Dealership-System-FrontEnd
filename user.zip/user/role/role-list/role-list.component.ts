/**
 * @summary  Generates and displays a dynamic list based on the role passed to it.
 *
 * @class RoleListComponent
 *
 * @returns selectedRole      When an item on the list is selected an event will be fired that contains the selected content.
 * @returns functionExecuted  When a function is executed an event will be fired that performs the function.
 */

import {Component, EventEmitter, OnInit, OnDestroy, Output} from "@angular/core";
import {Observable} from "rxjs/Observable";
import {Subscription} from "rxjs/Subscription";
import {ActivatedRoute, Router} from "@angular/router";
import {Role} from "../../model/role";
import {RoleService} from "../role.service";

import {ConfirmComponent} from '../../../shared/alert/confirm/confirm.component';
import {NgbModal, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-role-list',
  templateUrl: './role-list.component.html',
  styleUrls: ['./role-list.component.scss']
})
export class RoleListComponent implements OnInit, OnDestroy {


  @Output() functionExecuted: EventEmitter<any> = new EventEmitter();

  roleList: Array<Role>;

  /**
   * Pagination
   */
  currentPage: number;
  totalPages: number;
  totalElements: number;
  pageSize: number;
  sort: any;

  /**
   * Search bar & filters
   */
  search: any;
  filter: any = { 'Deleted': 0};

  /**
   * Role change related variables
   */
  roleListChange: Observable<any>;
  roleListChangeSub: Subscription;
  statusChange: Observable<string>;
  statusChangeSub: Subscription;
  functions: Array<any>;
  loading: boolean;

  canEditRole : boolean;


  constructor(private roleService: RoleService, private router:Router, private route: ActivatedRoute, private modalService: NgbModal) {
    // this.permissionService = permService;
    // this.canEditRole = this.permissionService.hasDefined('RL.ED'); // Example of using permission service in component
    this.roleList = [];
    this.roleListChange = this.roleService.subscribeToList();

    this.currentPage = 1;
    this.pageSize = 10;
    this.sort = null;

    this.totalPages = 0;
    this.totalElements = 0;

    this.functions = [{
        'function': 'selectRole',
        'label': 'Edit',
        'class': 'fa-pencil'
      },
      {
        'function': 'delete',
        'label': 'Delete',
        'class': 'fa-trash'
      }];
    this.statusChange = this.roleService.subscribeToStatus();
    this.statusChange.subscribe(status => {
      if (status === 'loading') {
        this.loading = true;
      }
      else {
        this.loading = false;
      }
    });
  }

  ngOnInit(): void {
    this.roleListChangeSub = this.roleListChange.subscribe(list => {
      this.roleList = list.roles;
      this.totalPages = list.pages;
      this.totalElements = list.elements;
    });
    this.roleService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter);
  }

  ngOnDestroy()
  {
      this.roleListChangeSub.unsubscribe();
  }

  /**
   * This method is used to select a role.
   *
   * @param role   The role that is selected
   */
  selectRole(role: Role): void {
     this.router.navigate(['./edit/'+role.Id], {relativeTo: this.route});
  }

  /**
   * This method is used to display a new page.
   *
   * @param page  The number of the page that is selected
   */
  changePage(page: number) {
    this.currentPage = page;
    this.roleService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter);
  }

  /**
   * This method is used to change the size of a page (amount of items displayed per page).
   *
   * @param size   The amount of items that need to be displayed per page
   */
  changePageSize(size: number) {
    this.pageSize = size;
    this.currentPage = 1;
    this.roleService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter);
  }

  /**
   * This function allows for the child list component to execute functions in the parent class.
   *
   * @param func   The function that should be executed
   */
  executeFunction(func: any): void {
    this[func['function']](func['obj']);
    this.functionExecuted.emit(func['function']);
  }

  /**
   * This method is used to toggle between 'active' & 'inactive'.
   *
   * @param role  The role that should be toggled
   */
  toggle(role: Role): void {
    this.roleService.toggle(role);
  }

  /**
   * This method is used to delete a role.
   *
   * @param role  The role that should be deleted
   */
  delete(roles: Role[]): void {
    this.roleService.delete(roles);
  }

  /**
   * This method is used to sort role content per column.
   *
   * @param sort  The data that should be sorted
   */
  doSort(sort: any): void {
    this.sort = sort;
    this.currentPage = 1;
    this.roleService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter);
  }

  /**
   * This method is used to search role data.
   *
   * @param search  The phrase(s) for which content should be searched
   */
  doSearch(search: any): void {
    this.search = search;
    this.currentPage = 1;
    this.roleService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter);
  }

  /**
   * This method is used to filter role data per column.
   *
   * @param filtere  The phrase(s) for which content should be filtered
   */
  doFilter(filter: any): void {
    this.filter = filter;
    this.currentPage = 1;
    this.roleService.listPage(this.currentPage, this.pageSize, this.sort, this.search, this.filter);
  }

  doCreate() {
    this.router.navigate(['./create'], {relativeTo: this.route});
  }

  openConfirmModal(roles: Role[]) {
    const options: NgbModalOptions = {
        size: 'sm'
    };

    const modalRef = this.modalService.open(ConfirmComponent, options);

    modalRef.componentInstance.titleText = 'GENERAL.CONFIRM.TEXT';
    modalRef.componentInstance.mainText = 'GENERAL.CONFIRM.MAIN_TEXT';

    modalRef.result
        .then(close => {
            this.delete(roles);
        }, dismissed => {
            // Remain silent if dismissed
        });
}

}
