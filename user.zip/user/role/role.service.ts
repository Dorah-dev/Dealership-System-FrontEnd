/**
 * Communication of RoleList & RoleForm with API endpoints -
 * contain custom methods: assign, listPage, fetch, create, update, toggle,
 * delete, subscribeToStatus, subscribeToList, subscribeToForm.
 *
 * @summary   Service to communicate between RoleListComponent & RoleFormComponent.
 *
 * @class RoleService
 */

import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Subject} from 'rxjs/Subject';
import {TranslateService} from '@ngx-translate/core';


import {Role} from '../model/role';

import {ApiService} from '../../core/api/api.service';
import {AlertService} from '../../shared/alert/alert.service';
import {ModelService} from '../../shared/interfaces/model-service';
import {HttpHeaders} from '@angular/common/http';


@Injectable()
export class RoleService implements ModelService {

    roleList: Array<Role>;
    roleListSubscription: Subject<any>;
    roleFormSubscription: Subject<Role>;
    status: Subject<string>;

    pageSize;
    currentPage;

    constructor(private api: ApiService, private alert: AlertService, private translate: TranslateService) {
        this.roleList = [];
        this.roleListSubscription = new Subject();
        this.roleFormSubscription = new Subject();
        this.status = new Subject();
        this.status.next('notLoaded');

        this.pageSize = 10;
        this.currentPage = 1;
    }

    /**
     * This method is used to assign data to the roles array.
     *
     * @param data This is the data that is assigned
     * @param headers This is the header of the page
     */
    assign(data: Array<Role>, headers: HttpHeaders): void {
        const roles = [];
        data.forEach((value: any, key: any) => {
            const role = new Role();
            role.fromJSON(value);
            roles.push(role);
        });

        const role_data = {
            roles: roles,
            pages: headers.get('X-Pages'),
            elements: headers.get('X-Count')
        };
        this.roleListSubscription.next(role_data);
    }

    /**
     * This method is used to list requested data.
     *
     * @param page      The page to retrieve of the list set
     * @param pageSize  The page size of the page to retrieve
     * @param sort      A sorting object to pass
     * @param search    Remaining search parameters
     * @param filter    Filter parameters
     */
    listPage(page?: number, pageSize: number = 1, sort: any = null, search: string = null, filter: any = {}): void {
        this.status.next('loading');

        // If there is no supplied filter for delete,
        // add a Deleted=false filter to only list available items.
        if (Object.keys(filter).indexOf('Deleted') === -1) {
            filter['Deleted'] = 'false';
        }

        this.api.list('Roles', page, pageSize, sort, true, search, filter)
            .subscribe(
                data => {
                    this.status.next('ready');
                    this.assign(data.body, data.headers);
                },
                error => {
                    this.status.next('error');
                }
            );
    }

    /**
     * This method is used to fetch requested data.
     *
     * @param id This is the id of the role that is fetched
     */
    fetch(id: number,
          filter: any = {},
          withParams: Array<string> = null): void {
        this.status.next('loading');
        if (!withParams) {
            withParams = ['rolefeatures', 'jobtitleroles'];
        }
        this.api.fetch('Roles', id, filter, withParams).subscribe(
            data => {
                this.roleFormSubscription.next(data.body);
                this.status.next('ready');

            },
            error => {
                this.status.next('error');
            }
        );

    }

    /**
     * This method is used to create a role by posting (save) data.
     *
     * @param role This is the role that uses POST method
     */
    create(role: Role): void {
        this.status.next('loading');
        delete role.Id;
        this.api.create('Roles', role).subscribe(
            data => {
                this.translate.get('ROLES.ALERT.SUCCESS_CREATE', {'role': role.Name})
                    .subscribe((res: string) => {
                        this.alert.success(res);
                    });
                this.listPage(this.currentPage, this.pageSize, null, null);
                this.status.next('ready');
            },
            error => {
                this.alert.error(error);
                this.status.next('error');
            }
        );
    }

    /**
     * This method is used to update a role by putting (update) data.
     *
     * @param role TThis is the role that uses PUT method
     */
    update(role: Role): void {
        this.status.next('loading');
        this.api.update('Roles/' + role.Id, role).subscribe(
            data => {
                this.translate.get('ROLES.ALERT.SUCCESS_UPDATE', {'role': role.Name})
                    .subscribe((res: string) => {
                        this.alert.success(res);
                    });
                this.status.next('ready');
            },
            error => {
                this.alert.error(error);
                this.status.next('error');
            }
        );
    }

    bulkUpdate(roles: Role[]): void {
        this.status.next('loading');
        this.api.update('Roles/', roles).subscribe(
            data => {

                this.listPage(1, this.pageSize);
                this.translate.get('ROLES.ALERT.SUCCESS_DELETE_MULTI')
                    .subscribe((res: string) => {
                        this.alert.success(res);
                    });
                this.status.next('ready');
            },
            error => {
                this.status.next('error');
                this.translate.get('ROLES.ALERT.FAIL_DELETE')
                    .subscribe((res: string) => {
                        this.alert.error(res);
                    });
            }
        );
    }

    /**
     * This method is used to toggle a role to be active / inactive.
     *
     * @param role This is the role that is toggled
     */
    toggle(role: Role): void {
        role.Active = !role.Active;
        this.update(role);
    }

    /**
     * This method is used to delete a role.
     *
     * @param role This is the role that uses the DELETE method
     */
    delete(roles: Role[]): void {
        for (let i = 0; i < roles.length; i++) {
            delete roles[i].formProperties;
            roles[i].Deleted = true;
        }
        this.bulkUpdate(roles);
    }

    /**
     * This method is used to subscribe to the status.
     */
    subscribeToStatus(): Observable<string> {
        return this.status.asObservable();
    }

    /**
     * This method is used to subscribe to the list component.
     */
    subscribeToList(): Observable<any> {
        return this.roleListSubscription.asObservable();
    }

    /**
     * This method is used to subscribe to the form component.
     */
    subscribeToForm(): Observable<Role> {
        return this.roleFormSubscription.asObservable();
    }

}
