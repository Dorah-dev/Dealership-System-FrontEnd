import {JobTitle} from './jobTitle';
import {Feature} from './feature';
import {Role} from './role';
import {ToyotaModel} from '../../shared/interfaces/toyota-model';
import {Serializable} from '../../shared/interfaces/serializable';
import {User} from './user';
/**
 * @summary Contains the model for Staff
 *
 * @class Staff
 */

export class Staff extends ToyotaModel implements Serializable {

    /**
     * Staff properties.
     */
    Id: number;
    PhoneNumber: string;
    ShortName: string;
    IDNumber: string;
    EmployeeNumber: string;
    Surname: string;
    FirstName: string;
    JobTitle: string;
    Dealership: string;
    Email: string;
    Initial: string;
    Birthday: Date;
    DateCreaded: Date;
    IsApplyBranding: boolean;
    IsTechnicalAdvisor: boolean;
    IsShowVideo: boolean;
    IsReminderImported: boolean;
    isNoQuoteApprove: boolean;
    isNoDiscRestrict: boolean;
    DMPortalFilter: string;
    Active: boolean;
    Deleted: boolean;
    UserId: Number;
    DealershipName: string;

    User: User;
    JobTitles: Array<JobTitle>;
    UserRoles: Array<Role>;
    UserFeatures: Array<Feature>;
    /**
     * Form & List properties to determine how & where staff properties are displayed.
     */
    formProperties = {
        editable: ['UserRole', 'UserFeatures'], //fields that can be edited
        form: ['Id', 'EmployeeNumber', 'FirstName', 'Surname', 'Dealership', 'PhoneNumber', 'Email', 'UserRole', 'UserFeatures'], //properties displayed on the form

        formLayout: [ //creating sections in form layout
            {
                'column': 6,
                'panels': [
                    {'id': 1, 'fields': ['EmployeeNumber', 'FirstName', 'Surname']},
                    {
                        'id': 3,
                        'fields': ['UserRoles'],
                        'column': "6",
                        'heading': 'ROLES.TITLE',
                        'display': 'edit',
                        'displayCondition': {'property': 'User', 'value': 'DEFINED'}
                    }
                ]
            },
            {
                'column': 6,
                'panels': [
                    {'id': 2, 'fields': ['PhoneNumber', 'Email', 'DealershipName']},
                    {
                        'id': 4,
                        'fields': ['UserFeatures'],
                        'heading': 'FEATURES.TITLE',
                        'display': 'edit',
                        'displayCondition': {'property': 'User', 'value': 'DEFINED'}
                    }
                ]
            }
        ],
        formTypes: {},
        labels: {
            'Id': 'COMMON.LABELS.ID',
            'EmployeeNumber': 'STAFF.LABELS.EMPLOYEE_NUMBER',
            'FirstName': 'COMMON.LABELS.FIRST_NAME',
            'Surname': 'COMMON.LABELS.LAST_NAME',
            'DealershipName': 'DEALERSHIP.LABELS.NAME',
            'PhoneNumber': 'COMMON.LABELS.PHONE_NUMBER',
            'Email': 'COMMON.LABELS.EMAIL',
            'UserRoles': null,
            'Features': null
        }, //labels on form & list
        list: [{ //properties displayed on the list
            headerCheckboxable: false,
            sortable: false,
            checkboxable: false,
            width: 30,
            resizeable: false,
            canAutoResize: false
        },
            {prop: 'Id'},
            {prop: 'EmployeeNumber', sortable: false},
            {prop: 'FirstName'},
            {prop: 'Surname'},
            {prop: 'DealershipName', sortable: false},
            {prop: 'PhoneNumber'},
            {prop: 'Email'},

        ], //properties displayed on the list
        mobile: [ //properties displayed on the Accordion for mobile view
            {prop: 'Id', header: true},
            {prop: 'EmployeeNumber', header: false},
            {prop: 'FirstName', header: true},
            {prop: 'Surname', header: true}
        ],

        load: { // how a section should be loaded
            'UserRoles': {
                'url': 'Roles?with=rolefeatures&Deleted=false',
                'convert': 'Role',
                'type': 'tree',
                'id': 'Id',
                'display': 'Name',
                'foreign': 'RoleId',
                'foreignMap': {'Name': 'RoleName', 'Description': 'RoleDescription', 'Code': 'RoleCode'},
                'ignoreChild': ['RoleFeatures']
            },
            'UserFeatures': {
                'url': 'modules?with=Components,Features,Deleted=false',
                'type': 'tree',
                'highlight': {'list': 'UserRoles', 'property': 'RoleFeatures', 'key': 'FeatureId'},
                'id': 'Id',
                'display': 'Name',
                'foreign': 'FeatureId',
                'foreignMap': {
                    'Name': 'FeatureName',
                    'Description': 'FeatureDescription',
                    'Code': 'FeatureCode',
                    'RoleFeatures': 'RoleFeatures'
                }
            },
        }, //how a section should be loaded
        primaryKey: 'Id', //primary key
        required: [], //fields that requires input
        sortable: ['Id', 'FirstName', 'Surname', 'PhoneNumber', 'Email'], //columns that can be sorted on list
        toggleable: false, //allows toggleability
        validation: { //validation on input fields
            validateAs: {},
            maxLength: {},
            minLength: {},
            confirm: []
        }
    };


    constructor(Id: number = 0,
                PhoneNumber: string = "",
                ShortName: string = "",
                IDNumber: string = "",
                EmployeeNumber: string = "",
                Surname: string = "",
                FirstName: string = "",
                JobTitle: string = "",
                Dealership: string = "",
                Email: string = "",
                Initial: string = "",
                Birthday: Date = null,
                DateCreaded: Date = null,
                IsApplyBranding: boolean = true,
                IsTechnicalAdvisor: boolean = false,
                IsShowVideo: boolean = true,
                IsReminderImported: boolean = true,
                isNoQuoteApprove: boolean = false,
                isNoDiscRestrict: boolean = false,
                DMPortalFilter: string = "",
                Active: boolean = true,
                Deleted: boolean = false,
                UserId: Number = 0,
                DealershipName: string = "",
                JobTitles: Array<JobTitle> = [],
                UserRoles: Array<Role> = [],
                UserFeatures: Array<Feature> = []) {
        super();
        this.Id = Id;
        this.PhoneNumber = PhoneNumber;
        this.ShortName = ShortName;
        this.IDNumber = IDNumber;
        this.EmployeeNumber = EmployeeNumber;
        this.Surname = Surname;
        this.FirstName = FirstName;
        this.JobTitle = JobTitle;
        this.Dealership = Dealership;
        this.Email = Email;
        this.Initial = Initial;
        this.Birthday = Birthday;
        this.IsApplyBranding = IsApplyBranding;
        this.IsTechnicalAdvisor = IsTechnicalAdvisor;
        this.IsShowVideo = IsShowVideo;
        this.IsReminderImported = IsReminderImported;
        this.isNoQuoteApprove = isNoQuoteApprove;
        this.isNoDiscRestrict = isNoDiscRestrict;
        this.DMPortalFilter = DMPortalFilter;
        this.Active = Active;
        this.Deleted = Deleted;
        this.UserId = UserId;
        this.DealershipName = DealershipName;
        this.JobTitles = JobTitles;
        if (!this.JobTitles) {
            this.JobTitles = [];
        }
        this.UserFeatures = UserFeatures;
        if (!this.UserFeatures) {
            this.UserFeatures = [];
        }
        this.UserRoles = UserRoles;
        if (!this.UserRoles) {
            this.UserRoles = [];
        }
    }

    fromJSON(obj: any) {
        this.Id = obj.Id;
        this.PhoneNumber = obj.PhoneNumber;
        this.ShortName = obj.ShortName;
        this.IDNumber = obj.IDNumber;
        if (obj.StaffDealershipDepartments && obj.StaffDealershipDepartments.length > 0) {
            this.EmployeeNumber = obj.StaffDealershipDepartments[0].EmployeeNumber;
        }
        this.Surname = obj.Surname;
        this.FirstName = obj.FirstName;
        this.JobTitle = obj.JobTitle;
        this.Dealership = obj.Dealership;
        this.Email = obj.Email;
        this.Initial = obj.Initial;
        this.Birthday = obj.Birthday;
        this.IsApplyBranding = obj.IsApplyBranding;
        this.IsTechnicalAdvisor = obj.IsTechnicalAdvisor;
        this.IsShowVideo = obj.IsShowVideo;
        this.IsReminderImported = obj.IsReminderImported;
        this.isNoQuoteApprove = obj.isNoQuoteApprove;
        this.isNoDiscRestrict = obj.isNoDiscRestrict;
        this.DMPortalFilter = obj.DMPortalFilter;
        this.Active = obj.Active;
        this.Deleted = obj.Deleted;
        this.UserId = obj.UserId;

        if (obj.StaffDealershipDepartments && obj.StaffDealershipDepartments.length > 0) {
            if (obj.StaffDealershipDepartments[0].DealershipDepartment) {
                if (obj.StaffDealershipDepartments[0].DealershipDepartment.Dealership) {
                    this.DealershipName = obj.StaffDealershipDepartments[0].DealershipDepartment.Dealership.Name;
                }
            }
        }

        this.JobTitles = obj.JobTitles;
        if (!this.JobTitles) {
            this.JobTitles = [];
        }
        if (obj.User) {
            this.User = new User;
            this.User.fromJSON(obj.User);
            this.UserFeatures = obj.User.UserFeatures;
            if (!this.UserFeatures) {
                this.UserFeatures = [];
            }

            this.UserRoles = obj.User.UserRoles;
            if (!this.UserRoles) {
                this.UserRoles = [];
            }
        }
        else {
            this.UserFeatures = [];
            this.UserRoles = [];
        }

    }

    toJSON() {
        return {
            'Id': this.Id,
            'PhoneNumber': this.PhoneNumber,
            'ShortName': this.ShortName,
            'IDNumber': this.IDNumber,
            'EmployeeNumber': this.EmployeeNumber,
            'Surname': this.Surname,
            'FirstName': this.FirstName,
            'JobTitle': this.JobTitle,
            'Dealership': this.Dealership,
            'Email': this.Email,
            'Initial': this.Initial,
            'Birthday': this.Birthday,
            'DateCreaded': this.DateCreaded,
            'IsApplyBranding': this.IsApplyBranding,
            'IsTechnicalAdvisor': this.IsTechnicalAdvisor,
            'IsShowVideo': this.IsShowVideo,
            'IsReminderImported': this.IsReminderImported,
            'isNoQuoteApprove': this.isNoQuoteApprove,
            'isNoDiscRestrict': this.isNoDiscRestrict,
            'DMPortalFilter': this.DMPortalFilter,
            'Active': this.Active,
            'Deleted': this.Deleted,
            'UserId': this.UserId,
            'DealershipName': this.DealershipName,
            'JobTitles': this.JobTitles,
            'UserRoles': this.UserRoles,
            'UserFeatures': this.UserFeatures
        }
    }

    get DisplayName() {
        return this.FirstName + ' ' + this.Surname;
    }

    get DisplayInitials() {
        let i = "";

        if (this.FirstName && this.FirstName.length > 0) {
            i += this.FirstName[0].toUpperCase();
        }

        if (this.Surname && this.Surname.length > 0) {
            i += this.Surname[0].toUpperCase()
        }

        return i;
    }
}
