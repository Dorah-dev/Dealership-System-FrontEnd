import {ToyotaModel} from "../../shared/interfaces/toyota-model";
import {Serializable} from "../../shared/interfaces/serializable";
/**
 * @summary Contains the model for Features
 *
 * @class Feature
 */

export class Feature extends ToyotaModel implements Serializable {

  /**
   * Feature properties.
   */
  Id: number;
  Name: string;
  Active: boolean;
  Deleted: boolean;
  CreatedAt: Date;
  DeletedAt: Date;

  /**
   * Form & List properties to determine how & where feature properties are displayed.
   */
  formProperties = {
    editable: ['Name', 'Active'], //fields that can be edited
    form: ['Name', 'Active'], //properties displayed on the form
    labels: {'Name': 'COMMON.LABELS.NAME', 'Active': 'COMMON.LABELS.ACTIVE'}, //labels on form & list
    list: ['Name', 'Active'], //properties displayed on the list
    load: {}, //how a section should be loaded
    primaryKey: 'Id', //primary key
    required: ['Name'], //fields that requires input
    validation: { //validation on input fields
      validateAs: {},
      maxLength: {},
      minLength: {}
    }
  };

  /**
   * Feature constructor
   *
   * @param id    The id of the feature that should be edited or viewed
   * @param name    The name of the feature that should be edited or viewed
   * @param active  Determines whether the feature is active or inactive
   * @param deleted  Determines whether the feature is deleted or not
   * @param createdAt  Log of the date on which the feature was created
   * @param deletedAt  Log of the date on which the feature was deleted
   */
  constructor(Id: number = 0, Name: string = "", Active: boolean = true, Deleted: boolean = false, CreatedAt: Date = new Date(), DeletedAt: Date = new Date()) {
    super();
    this.Id = Id;
    this.Name = Name;
    this.Active = Active;
    this.Deleted = Deleted;
    this.CreatedAt = CreatedAt;
    this.DeletedAt = DeletedAt;
  }

  toJSON() {
    return {
      'Id': this.Id,
      'Name': this.Name,
      'Active': this.Active,
      'Deleted': this.Deleted,
      'CreatedAt': this.CreatedAt,
      'DeletedAt': this.DeletedAt
    }
  }

  fromJSON(obj: any) {
    // TODO - didnt have an updateFromJson initially
    throw new Error('Method not implemented.');
  }
}
