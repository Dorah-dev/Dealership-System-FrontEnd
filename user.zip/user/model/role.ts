/**
 * Imported models used in Role class.
 */
import {Feature} from "./feature";
import {JobTitle} from "./jobTitle";
import {ToyotaModel} from "../../shared/interfaces/toyota-model";
import {Serializable} from "../../shared/interfaces/serializable";

/**
 * @summary Contains the model for Roles
 *
 * @class Role
 */
export class Role extends ToyotaModel implements Serializable {

  /**
   * Role properties.
   */
  Id: number;
  Name: string;
  Description: string;
  Code: string;
  Active: boolean;
  Deleted: boolean;
  CreatedAt: Date;
  ModifiedAt: Date;

  RoleFeatures: Array<Feature>;
  JobTitleRoles: Array<JobTitle>;

  /**
   * Form & List properties to determine how & where role properties are displayed.
   */
  formProperties = {
    editable: ['Name', 'Description', 'Code', 'Active', 'RoleFeatures', 'JobTitleRoles'], //fields that can be edited
    permissions: { // what permission do you need to have access to a specific field
      'Active': 'RMDEL',
      'Delete': 'RMDEL'
    },
    form: ['Name', 'Description', 'Code', 'Active', 'RoleFeatures', 'JobTitleRoles'], //properties displayed on the form
    formTypes: {},
    formLayout: [ //creating sections in form layout
      {
        'column': 6,
        'panels': [
          {'id': 1, 'fields': ['Name', 'Description', 'Code', 'Active'], 'column': "6"},
          {'id': 3, 'fields': ['JobTitleRoles'], 'column': "6", 'heading': 'JOB_TITLES.TITLE'}
        ]
      },
      {
        'column': 6,
        'panels': [
          {'id': 2, 'fields': ['RoleFeatures'], 'column': "6", 'heading': 'FEATURES.TITLE'}
        ]
      }
    ],
    labels: { //labels on form & list
      'Code': 'COMMON.LABELS.CODE',
      'Name': 'COMMON.LABELS.NAME',
      'Description': 'COMMON.LABELS.DESCRIPTION',
      'Active': 'COMMON.LABELS.ACTIVE',
      'RoleFeatures': null,
      'RoleJobTitles': null,
      'CreatedAt': 'COMMON.LABELS.CREATED',
      'ModifiedAt': 'COMMON.LABELS.MODIFIED'
    },
    list: [{ //properties displayed on the list
      headerCheckboxable: true,
      sortable: false,
      checkboxable: true,
      width: 30,
      resizeable: false,
      canAutoResize: false
    },
      {prop: 'Name'},
      {prop: 'Code'},

      {
        prop: 'Active',
        type: 'toggle'
      }],
     mobile: [ //properties displayed on the Accordion for mobile view
      {prop: 'Code', header:true},
      {prop: 'Name', header:true},
      {prop: 'Description', header:false},
    ],
    load: { //how a section should be loaded
      'RoleFeatures': {
        'url': 'modules?with=Components,Features&Deleted=false',
        'type': 'tree',
        'id': 'Id',
        'display': 'Name',
        'foreign': 'FeatureId',
        'foreignMap': {'Name': 'FeatureName', 'Description': 'FeatureDescription', 'Code': 'FeatureCode'}
      },
      'JobTitleRoles': {
        'url': 'JobTitles?Deleted=false',
        'type': 'tree',
        'id': 'Id',
        'display': 'Name',
        'foreign': 'JobTitleId',
        'foreignMap': {'Name': 'JobTitleName', 'Level': 'JobTitleLevel', 'Code': 'JobTitleCode'}
      }
    },
    primaryKey: 'Id', //primary key
    required: ['Name', 'Description', 'Code'], //fields that requires input
    sortable: ['Code', 'Name'], //columns that can be sorted on list
    toggleable: true, //allows toggleability
    validation: { //validation on input fields
      validateAs: {'Name':'pattern'},
      maxLength: {},
      minLength: {},
      validationParams: {
          'Name': '^(?!\\s*$).+'
      },
      confirm: []
    }
  };

  /**
   * Role constructor
   *
   * @param id             The id of role that should be edited or viewed
   * @param name           The name of role that should be edited or viewed
   * @param description    The description of role that should be edited or viewed
   * @param code           The code of role that should be edited or viewed
   * @param active         Determines whether role is active or inactive
   * @param deleted        Determines whether role is deleted or not
   * @param createdAt      Log of the date on which role was created
   * @param modifiedAt     Log of the date on which role was modified
   * @param roleJobTitles  The array of job titles for a role
   * @param roleFeatures   The array of features for a role
   */
  constructor(Id: number = 0,
              Name: string = '',
              Description: string = '',
              Code: string = '',
              Active: boolean = true,
              Deleted: boolean = false,
              CreatedAt: Date = new Date(),
              ModifiedAt: Date = new Date(),
              RoleFeatures: Array<Feature> = [],
              JobTitleRoles: Array<JobTitle> = []) {
    super();
    this.Id = Id;
    this.Name = Name;
    this.Description = Description;
    this.Code = Code;
    this.Active = Active;
    this.Deleted = Deleted;
    this.CreatedAt = CreatedAt;
    this.ModifiedAt = ModifiedAt;

    this.RoleFeatures = RoleFeatures;
    if (!this.RoleFeatures) {
      this.RoleFeatures = [];
    }

    this.JobTitleRoles = JobTitleRoles;
    if (!this.JobTitleRoles) {
      this.JobTitleRoles = [];
    }
  }

  fromJSON(obj: any) {
    this.Id = obj.Id;
    this.Name = obj.Name;
    this.Description = obj.Description;
    this.Code = obj.Code;
    this.Active = obj.Active;
    this.Deleted = obj.Deleted;
    this.CreatedAt = obj.CreatedAt;
    this.ModifiedAt = obj.ModifiedAt;

    this.RoleFeatures = obj.RoleFeatures;
    if (!this.RoleFeatures) {
      this.RoleFeatures = [];
    }
    this.JobTitleRoles = obj.JobTitleRoles;
    if (!this.JobTitleRoles) {
      this.JobTitleRoles = [];
    }
  }

  toJSON() {
    return {
      'Id': this.Id,
      'Name': this.Name,
      'Description': this.Description,
      'Code': this.Code,
      'Active': this.Active,
      'Deleted': this.Deleted,
      'CreatedAt': this.CreatedAt,
      'ModifiedAt': this.ModifiedAt,
      'RoleFeatures': this.RoleFeatures,
      'JobTitleRoles': this.JobTitleRoles
    }
  }
}
