/**
 * Imported models used in User class.
 */
import {Role} from './role';
import {Staff} from './staff';
import {Feature} from './feature';
import {Customer} from '../../customer/model/customer';
import {ToyotaModel} from '../../shared/interfaces/toyota-model';
import {Serializable} from '../../shared/interfaces/serializable';


/**
 * @summary Contains the model for Users
 *
 * @class User
 */
export class User extends ToyotaModel implements Serializable {

  /**
   * User properties.
   */
  Id: number;
  DateCreated: Date;
  DateModified: Date;
  UserName: string;
  Password: string;
  Active: boolean;
  Deleted: boolean;
  DateLastLogin: Date;

  /**
   * Imported from Staff , Customer  & Role
   */
  staff: Staff;
  customer: Customer;
  UserRoles: Array<Role>;
    Roles: Array<Role>;
  UserFeatures: Array<Feature>;

  /**
   * Form & List properties to determine how & where user properties are displayed.
   */
  formProperties = {
    editable: ['UserName', 'Password', 'UserFeatures', 'UserRoles', 'Active'], // fields that can be edited
    permissions: { // what permission do you need to have access to a specific field
      'Active': 'UMDEL',
      'Delete': 'UMDEL'
    },
    form: ['UserName', 'Password', 'Active', 'UserRoles'], // properties displayed on the form
    formLayout: [ // creating sections in form layout
      {
        'column': 6,
        'panels': [
            {'id': 1, 'fields': ['UserName']}
        ]
      },
      {
        'column': 6,
        'panels': [
            {
                'id': 2,
                'fields': ['Active', 'Password'],
                'hiddenFields': ['Password'],
                'hiddenLabel': 'USER.ACTIONS.CHANGE_PASSWORD'
            }
        ]
      },
        {
            'column': 6,
            'panels': [
                {'id': 3, 'fields': ['UserRoles'], 'heading': 'ROLES.TITLE', 'display': 'edit'}
            ]
        },
        {
            'column': 6,
            'panels': [
                {'id': 4, 'fields': ['UserFeatures'], 'heading': 'FEATURES.TITLE', 'display': 'edit'}
        ]
      }
    ],
    formTypes: {'Password': 'password'},
    labels: {
      'Id': 'COMMON.LABELS.ID',
      'UserName': 'USER.LABELS.USERNAME',
      'Password': 'USER.LABELS.PASSWORD',
      'Active': 'COMMON.LABELS.ACTIVE',
      'DateCreated': 'COMMON.LABELS.CREATED',
      'DateModified': 'COMMON.LABELS.MODIFIED',
      'FirstNameDisplay': 'COMMON.LABELS.FIRST_NAME',
      'SurnameDisplay': 'COMMON.LABELS.LAST_NAME',
      'IconDisplay': 'USER.LABELS.USER_TYPE_1'
    }, // labels on form & list
    list: [{ // properties displayed on the list
      headerCheckboxable: true,
      sortable: false,
      checkboxable: true,
      width: 30,
      resizeable: false,
      canAutoResize: false
    },
      {prop: 'Id'},
      {prop: 'FirstNameDisplay', sortable: false},
      {prop: 'SurnameDisplay', sortable: false},
      {prop: 'UserName', sortable: false},
      {prop: 'DateCreated', type: 'date'},
      {prop: 'DateModified', type: 'date'},
      {
        prop: 'Active',
        type: 'toggle'
      }, {
        prop: 'IconDisplay',
        type: 'icon',
        sortable: false
      }],
     mobile: [ //properties displayed on the Accordion for mobile view
      {prop: 'Id', header:false},
      {prop: 'FirstNameDisplay', header:true},
      {prop: 'SurnameDisplay', header:true}
    ],
    load: { // how a section should be loaded
      'UserRoles': {
        'url': 'Roles?with=rolefeatures&Deleted=false',
        'convert':'Role',
        'type': 'tree',
        'id': 'Id',
        'display': 'Name',
        'foreign': 'RoleId',
        'foreignMap': {'Name': 'RoleName', 'Description': 'RoleDescription', 'Code': 'RoleCode'},
        'ignoreChild':['RoleFeatures']
      },
      'UserFeatures': {
        'url': 'modules?with=Components,Features,Deleted=false',
        'type': 'tree',
        'highlight':{'list':'UserRoles', 'property':'RoleFeatures','key':'FeatureId'},
        'id': 'Id',
        'display': 'Name',
        'foreign': 'FeatureId',
        'foreignMap': {'Name': 'FeatureName', 'Description': 'FeatureDescription', 'Code': 'FeatureCode', 'RoleFeatures':'RoleFeatures'}
      },
    },
    primaryKey: 'Id', // primary key
    required: ['UserName', 'Password',], // fields that requires input
    sortable: ['DateCreated', 'DateModified'], // columns that can be sorted on list
    toggleable: true, // allows toggleability
    validation: { // validation on input fields
      validateAs: {'UserName': 'email'},
      maxLength: {},
      minLength: {},
      confirm: ['Password']
    }
  };

  /**
   * User constructor
   *
   * @param id                   The id of user that should be edited or viewed
   * @param userName             The user name of user that should be edited or viewed
   * @param password             The password of user that should be edited or viewed
   * @param active               Determines whether user is active or inactive
   * @param deleted              Determines whether user is deleted or not
   * @param dateLastLogin        Log of last date the user was logged in
   * @param dateCreated          Log of date the user was created
   * @param dateModified         Log of date the user was modified
   * @param staff                The information for a staff user
   * @param customer             The information for a customer user
   * @param userRoles            The array of user roles for a user
   * @param userFeatures         The array of user features for a user
   */
  constructor(Id: number = 0,
              UserName: string = '',
              Password: string = '',
              Active: boolean = true,
              Deleted: boolean = false,
              DateLastLogin: Date = null,
              DateCreated: Date = new Date(),
              DateModified: Date = new Date(),
              staff: Staff = null,
              customer: Customer = null,
              UserRoles: Array<Role> = [],
              UserFeatures: Array<Feature> = []) {
    super();
    this.Id = Id;
    this.DateCreated = DateCreated;
    this.DateModified = DateModified;
    this.Active = Active;
    this.Deleted = Deleted;
    this.UserName = UserName;
    this.Password = Password;
    if (this.Password === null) {
      this.Password = '';
    }
    this.DateLastLogin = DateLastLogin;

    const newStaff = new Staff();
    if (staff) {
      newStaff.fromJSON(staff);
    }
    this.staff = newStaff;

    const newCustomer = new Customer();
    if (customer) {
      newCustomer.fromJSON(customer);
    }
    this.customer = newCustomer;

    // TODO: Should recreate individual objects
    this.UserRoles = UserRoles;
    if (!this.UserRoles) {
      this.UserRoles = [];
    }

    // TODO: Should recreate individual objects
    this.UserFeatures = UserFeatures;
    if (!this.UserFeatures) {
      this.UserFeatures = [];
    }
  }

  fromJSON(obj: any) {
    this.Id = obj.Id;
    this.DateCreated = obj.DateCreated;
    this.DateModified = obj.DateModified;
    this.UserName = obj.UserName;
    this.Password = obj.Password;
    if (this.Password === null) {
      this.Password = '';
    }
    this.Active = obj.Active;
    this.Deleted = obj.Deleted;
    this.DateLastLogin = obj.DateLastLogin;

    const newStaff = new Staff();
    if (obj.Staff) {
      newStaff.fromJSON(obj.Staff);
    }
    this.staff = newStaff;

    const newCustomer = new Customer();
    if (obj.Customers) {
      newCustomer.fromJSON(obj.Customers);
    }
    this.customer = newCustomer;

    this.UserRoles = obj.UserRoles;
    if (!this.UserRoles) {
      this.UserRoles = [];
    }

      this.Roles = [];
      for (let x = 0; x < this.UserRoles.length; x++) {
          this.Roles.push(this.UserRoles[x]['Role']);
      }

    this.UserFeatures = obj.UserFeatures;
    if (!this.UserFeatures) {
      this.UserFeatures = [];
    }

  }

  toJSON() {
    return {
      'Id': this.Id,
      'DateCreated': this.DateCreated,
      'DateModified': this.DateModified,
      'UserName': this.UserName,
      'Password': this.Password,
      'Active': this.Active,
      'Deleted': this.Deleted,
      'DateLastLogin': this.DateLastLogin,
      'UserRoles': this.UserRoles,
      'UserFeatures': this.UserFeatures
    }
  }

  get FirstNameDisplay(): string {
    if (this.staff && this.staff.Id !== null) {
      return this.staff.FirstName;
    } else if (this.customer && this.customer.Id !== null) {
      return this.customer.FirstName;
    } else {
      return 'None';
    }
  }

  get SurnameDisplay(): string {
    if (this.staff && this.staff.Id !== null) {
      return this.staff.Surname;
    } else if (this.customer && this.customer.Id !== null) {
      return this.customer.Surname;
    } else {
      return 'None';
    }
  }

  get IconDisplay(): string[] {
    let icons = [];

    if (this.staff && this.staff.Id !== null && this.staff.Id !== 0) {
      //staff
      icons.push('tft-icon-staff');
    }
    if (this.customer && this.customer.Id !== null && this.customer.Id !== 0) {
      //customer
      icons.push('tft-icon-customer');
    }

    return icons;
  }

}
