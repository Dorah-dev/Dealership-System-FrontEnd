import {Serializable} from "../../shared/interfaces/serializable";
import {ToyotaModel} from "../../shared/interfaces/toyota-model";
/**
 * @summary Contains the model for Job Titles
 *
 * @class JobTitle
 */

export class JobTitle extends ToyotaModel implements Serializable {


  /**
   * JobTitle properties.
   */
  Id: number;
  Name: string;
  Active: boolean;
  Level: number;
  Deleted: boolean;
  CreatedAt: Date;
  DeletedAt: Date;


  /**
   * Form & List properties to determine how & where job title properties are displayed.
   */
  formProperties = {
    editable: ['Name', 'Active'], //fields that can be edited
    form: ['Name', 'Active'], //properties displayed on the form
    labels: {'Name': 'COMMON.LABELS.NAME', 'Active': 'COMMON.LABELS.ACTIVE'}, //labels on form & list
    list: ['Name', 'Active'], //properties displayed on the list
    load: {}, //how a section should be loaded
    primaryKey: 'Id', //primary key
    required: ['Name'], //fields that requires input
    validation: { //validation on input fields
      validateAs: {},
      maxLength: {},
      minLength: {}
    }
  };

  /**
   * JobTitle constructor
   *
   * @param id    The id of the jobTitle that should be edited or viewed
   * @param name    The name of the jobTitle that should be edited or viewed
   * @param active  Determines whether the jobTitle is active or inactive
   * @param deleted  Determines whether the jobTitle is deleted or not
   * @param createdAt  Log of the date on which the jobTitle was created
   * @param deletedAt  Log of the date on which the jobTitle was deleted
   */
  constructor(Id: number = 0, Name: string = "", Level: number = 0, Active: boolean = true, Deleted: boolean = false, CreatedAt: Date = new Date(), DeletedAt: Date = new Date()) {
    super();
    this.Id = Id;
    this.Name = Name;
    this.Active = Active;
    this.Level = Level;
    this.Deleted = Deleted;
    this.CreatedAt = CreatedAt;
    this.DeletedAt = DeletedAt;
  }

  toJSON(): any {
    return {
      'Id': this.Id,
      'Name': this.Name,
      'Active': this.Active,
      'Level': this.Level,
      'Deleted': this.Deleted,
      'CreatedAt': this.CreatedAt,
      'DeletedAt': this.DeletedAt
    }
  }

  fromJSON(obj: any): any {
    // TODO - didnt have an updateFromJson initially
    return new Error('Method not implemented');
  }
}
